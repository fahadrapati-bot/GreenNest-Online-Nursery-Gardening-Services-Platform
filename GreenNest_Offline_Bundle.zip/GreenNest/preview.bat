@echo off
title GreenNest Production Preview
echo ===================================================
echo     GreenNest - Production Build Preview
echo ===================================================
echo.
cd /d "%~dp0"

echo Building latest production bundle...
call npm run build

echo Starting preview server and opening browser...
start http://localhost:4173
call npm run preview
pause
