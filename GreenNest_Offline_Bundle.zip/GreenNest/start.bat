@echo off
title GreenNest Platform Launcher
echo ===================================================
echo     Launching GreenNest Platform (Vite Dev Server)
echo     Online Nursery & Gardening Services Platform
echo ===================================================
echo.
cd /d "%~dp0"

echo [1/2] Checking dependencies...
if not exist "node_modules\" (
    echo Installing node dependencies, please wait...
    call npm install
)

echo [2/2] Starting server and opening browser...
start http://localhost:5173
call npm run dev
pause
