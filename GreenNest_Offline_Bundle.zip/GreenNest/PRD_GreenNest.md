# GreenNest – Online Nursery & Gardening Services Platform
## Comprehensive Product Requirements Document (PRD) & Technical Analysis

**Project Context:** Unified Mentor × Urbano Nursery Collaboration  
**Platform Name:** GreenNest  
**Version:** 1.0.0 (Production-Ready Release)  
**Author / Engineering Team:** Antigravity AI Engineering & Unified Mentor Solutions  
**Date:** September 2026  

---

## 1. Executive Summary & Context

With increasing urbanization, remote working lifestyle, and rising interest in indoor gardening and sustainable living, city residents face major challenges when attempting to maintain greenery in their apartments and homes. Currently:
1. Physical nursery visits are time-consuming, fragmented, and lack stock transparency.
2. Skilled, reliable gardeners are difficult to find, relying purely on informal word-of-mouth references without background checks, standardized tools, or predictable pricing.
3. Plants delivered via standard generic e-commerce often suffer transit shock or root damage due to inadequate packaging.

**GreenNest** addresses this market gap by delivering a unified digital marketplace and service booking ecosystem that brings together:
- **Urban Plant Parents & Homeowners** looking for quality indoor/outdoor plants, seeds, planters, and verified on-demand gardener visits.
- **Local Nurseries (e.g., Urbano Nursery)** digitizing their inventory, fulfilling orders, and expanding reach beyond physical foot traffic.
- **Independent Gardening Professionals (Gardeners)** gaining consistent, transparent, dignity-first service appointments and fair digital earnings.
- **Platform Administrators (Unified Mentor)** monitoring marketplace trust, vendor KYC approvals, order tracking, and service quality SLAs.

---

## 2. Problem Statement & Strategic Objectives

### 2.1 Problem Statement
- **Limited Local Nursery Access:** Customers are limited to whatever small roadside stalls exist in their immediate vicinity.
- **Lack of Transparent Pricing & Service Quality:** Traditional gardening services quote arbitrary manual prices and lack standard checklists.
- **Coordination Friction:** Service appointments are arranged via chaotic manual phone calls, leading to high cancellation and no-show rates.
- **Logistical Fragility:** Living flora requires specialized breathable, moisture-retaining packaging and fast regional transit.

### 2.2 Objectives

#### Primary Objectives
- Enable customers to discover, filter, and purchase acclimatized plants, seeds, and gardening equipment online.
- Provide a reliable booking engine for verified, background-checked gardeners with scheduled 2-hour visit slots.
- Provide nursery vendors with a self-service inventory console to manage pricing, stock, and fulfillment status.
- Enable end-to-end status visibility for both product shipments and gardener service appointments.

#### Secondary Objectives
- Encourage green, eco-friendly lifestyle through plant care reminders and personalized plant match quizzes.
- Support local brick-and-mortar nurseries by transforming them into high-efficiency digital fulfillment centers.
- Guarantee plant vitality through a 7-day plant replacement policy.

---

## 3. Scope of Work

### In-Scope (Phase 1)
- Responsive Single-Page Application (Desktop, Tablet, Mobile).
- Multi-Role Portal Simulation & Switching:
  - **Customer Hub** (Browse, Filter, Cart, Checkout, Order Tracking, Service Booking, Plant Reminders, Wishlist).
  - **Nursery Vendor Console** (Product Inventory CRUD, Order Fulfillment, Payout Reports).
  - **Gardener Pro Schedule** (Availability Toggle, Assigned Appointments, Status Updaters, Earnings).
  - **Platform Admin Operations** (KPIs, Vendor KYC Approvals, Catalog Oversight, Dispute Mediation).
- Interactive Plant Match Quiz engine based on ambient lighting and lifestyle.
- Cart with automated promo code engine (`GREEN10`, `URBANO20`), eco-packaging charge, and regional free-shipping rules.
- LocalStorage persistence with sample seed data reset capability.

### Out of Scope (Deferred to Future Iterations)
- Native mobile applications (iOS Swift / Android Kotlin) — Mobile-First PWA implemented instead.
- Cross-border international plant shipping (restricted by international phytosanitary quarantine laws).
- Automated hardware IoT soil sensor and smart sprinkler hub hardware integrations.
- Deep neural network image diagnosis for plant disease detection (Phase 2 Roadmap).

---

## 4. User Personas

| Persona | Name & Profile | Core Needs | Platform Solution |
| :--- | :--- | :--- | :--- |
| **Urban Plant Parent** | Aarav Sharma (28, Software Engineer) | Wants low-maintenance air-purifying plants for apartment; needs gardener to prune monstera and fix yellow leaves. | Guided catalog filters (Indoor, Low Light), interactive care guides, scheduled Sunday morning gardener booking. |
| **Nursery Owner** | Vikram Joshi (Urbano Nursery Manager) | Struggles with inventory overflow and rainy season footfall drops; wants digital sales channel. | Simple vendor portal to add plants, update prices and stock levels, and dispatch orders with single clicks. |
| **Gardener Pro** | Rajesh Kumar (Master Horticulturalist) | Seeks predictable weekly income, respectful customers, and professional digital identity. | Dedicated scheduling dashboard, hourly rate transparency, transparent client notes and directions. |
| **Platform Ops** | Unified Mentor Operations Admin | Requires total oversight of vendor authenticity, order conversion, and customer complaints. | Approval queue for new nursery applications, audit logs, and dispute resolution resolution workflow. |

---

## 5. Functional Requirements Specification

```mermaid
flowchart TD
    A["User Arrives at GreenNest"] --> B{"Choose Action"}
    B -->|"Buy Plants & Tools"| C["Browse Catalog with Filters"]
    B -->|"Book Gardener"| D["Select Gardening Package"]
    B -->|"Find Best Match"| E["Take 3-Question Plant Quiz"]
    
    C --> F["Add to Cart & Apply Coupon"]
    F --> G["Multi-Step Checkout & Address"]
    G --> H["Order Placed with Live Tracker"]
    
    D --> I["Choose Verified Pro & Time Slot"]
    I --> J["Confirm Garden Type & Notes"]
    J --> K["Service Booking Scheduled"]

    H --> L["Nursery Packs & Dispatches"]
    K --> M["Gardener Arrives & Completes Job"]
```

### 5.1 Customer Features
1. **Catalog Exploration & Filtering:**
   - Categories: Indoor Plants, Outdoor Plants, Flowering Pots, Seeds & Bulbs, Pots & Planters, Tools, Fertilizers & Soil.
   - Multi-attribute filtering by Environment (Indoor/Outdoor), Price brackets (Under $25, $25-$40, $40+), and Sunlight requirements (Low, Indirect Bright, Full Sun).
   - Instant search query matching product names, botanical nomenclature, descriptions, and tags.
   - Sorting by Featured, Price (Ascending/Descending), and Highest Customer Rating.
2. **Product Detail & Care Knowledge:**
   - High-resolution photography with stock status indicator.
   - Botanical specifications and care guide breakdown: Sunlight, Watering frequency, Soil type, Temperature, and Fertilizer cycle.
   - Quantity selector with direct cart integration.
3. **Cart & Checkout Workflow:**
   - Slide-over drawer with item increment/decrement and removal.
   - Coupon engine supporting `GREEN10` (10% off) and `URBANO20` (20% off).
   - Transparent bill breakdown: Subtotal, Discount, Eco-safe packaging, and Free Shipping calculation for orders over $50.
   - Multi-step checkout form: Recipient contact, street address, city, pin code, preferred delivery slot, and payment method (UPI / Cards / NetBanking / COD).
4. **Gardener Service Booking Engine:**
   - 4 standardized service packages: Comprehensive Home Gardening, Lawn Mowing & Turf Care, Plant Health & Pest Eradication, and Balcony Garden Setup Consultation.
   - Verified gardener directory with photo, credentials, rating, completed jobs count, and hourly pricing.
   - Interactive date selection and time windows (9:00 AM, 11:30 AM, 2:00 PM, 4:30 PM).
   - Space customization (Balcony, Terrace, Indoor Pots, Yard) and free-text notes for specific plant symptoms.
5. **Customer Dashboard & Live Tracking:**
   - **My Orders:** Live 4-stage visual progress stepper (`Placed` → `Packed` → `Out for Delivery` → `Delivered`), tracking number, and cancellation option.
   - **My Bookings:** Scheduled appointments with gardener phone contact, status indicator, and cancellation option.
   - **Custom Plant Care Reminders:** Interactive checklist for watering, misting, and organic fertilizing.
   - **Wishlist:** Saved bookmarked plants for one-click ordering.
6. **Plant Match Quiz:**
   - 3-step interactive recommendation wizard (Lighting condition → Gardening experience → Pet friendliness) that recommends the ideal botanical match.

### 5.2 Nursery Vendor Features (Urbano Nursery Console)
1. **Catalog & Inventory CRUD:**
   - View all active products with thumbnail, SKU, category, price, and current stock.
   - "List New Plant / Product" modal form with validation.
   - Inline edit for pricing and stock replenishment.
   - Instant de-list / delete option.
2. **Order Dispatch Queue:**
   - Live order stream showing customer details, items requested, and destination.
   - Status transitions: `Placed` → `Packed` → `Out for Delivery` → `Delivered`.
3. **Payout & Financial Settlements:**
   - Gross revenue volume tally.
   - Automated 10% platform fee deduction and 90% net payout calculation.

### 5.3 Gardener Pro Portal (Rajesh Kumar Console)
1. **Status & Availability Toggle:**
   - One-click toggle between `Available Today` and `Off-Duty`.
2. **Assigned Appointments Schedule:**
   - Detailed list of client visits including date, time window, address, client phone, garden type, and plant symptoms.
   - Workflow actions: `Accept Visit` → `Start Visit (In Progress)` → `Mark Completed`.
3. **Professional Performance Track:**
   - Rating meter (4.95 ★), completed jobs count (320+), and cumulative earnings calculator.

### 5.4 Platform Operations Admin (Unified Mentor Console)
1. **Executive Metrics (KPIs):**
   - Platform GMV, Order conversion rates, Active verified partners, and Open dispute counts.
2. **KYC & Partner Verification:**
   - Application queue for incoming nursery and gardener registrations.
   - Inspect agricultural license numbers, years of experience, and credentials.
   - One-click `Approve & Verify` or `Reject` actions.
3. **Marketplace Moderation:**
   - Global catalog oversight with authority to de-list violating items.
   - Master order and appointment audit log.
4. **Disputes & Customer Support Desk:**
   - Customer tickets (e.g. transit plant damage, schedule clashes).
   - Actionable resolution with free replacement issuance or claim dismissal.

---

## 6. System Architecture & Tech Stack

```
+-------------------------------------------------------------+
|                     Client Browser / PWA                    |
|  React 19 + Vite + Tailwind CSS v4 + Lucide Modern Icons    |
+-------------------------------------------------------------+
                               |
         +---------------------+---------------------+
         |                                           |
+--------------------------+             +--------------------------+
|  AppContext & State Hub  |             |  Local Storage Sync API  |
|  (Cart, Auth, Bookings)  |             |  (Cross-Session State)   |
+--------------------------+             +--------------------------+
                               |
+-------------------------------------------------------------+
|                   Seed & Master Data Layer                  |
|    Urbano Nursery Catalog, Botanical Care Guides, Pros      |
+-------------------------------------------------------------+
```

### Technical Stack Justification
- **Frontend Framework:** React 19 with Vite 8 for instant hot module reloading (HMR) and sub-second build times.
- **Styling Architecture:** Tailwind CSS v4 utilizing CSS variables, responsive typography, and nature-inspired emerald/forest color palettes.
- **Iconography:** `lucide-react` providing clean, tree-shakeable SVG icons for botanical elements, tools, and UI navigation.
- **Data Persistence:** Client-side reactive local storage persistence layer allowing all orders, new products, and bookings to survive page refreshes without requiring external database provisioning.
- **Zero-Dependency Runner:** Native Windows batch launchers (`start.bat`, `preview.bat`) for effortless pairing and grading.

---

## 7. Data Models & Entity Relationships

```mermaid
erDiagram
    USER ||--o{ ORDER : places
    USER ||--o{ BOOKING : schedules
    NURSERY ||--o{ PRODUCT : supplies
    PRODUCT ||--o{ ORDER_ITEM : contains
    ORDER ||--|{ ORDER_ITEM : includes
    GARDENER ||--o{ BOOKING : executes
    USER ||--o{ DISPUTE : files

    USER {
        string id PK
        string name
        string email
        string phone
        string address
        string role
    }

    PRODUCT {
        string id PK
        string name
        string botanicalName
        string category
        float price
        int stock
        string nurseryId FK
        json careGuide
    }

    BOOKING {
        string id PK
        string serviceId
        string gardenerId FK
        string customerId FK
        string date
        string timeSlot
        string status
        float price
    }

    ORDER {
        string id PK
        string customerId FK
        json items
        float total
        string status
        string trackingNumber
    }
```

---

## 8. REST API Specification (Contract Design)

| Endpoint | Method | Role | Description |
| :--- | :--- | :--- | :--- |
| `/api/v1/products` | `GET` | Public | List products with query parameters (`category`, `price`, `light`, `search`). |
| `/api/v1/products` | `POST` | Vendor, Admin | Create a new plant or supply listing with care specifications. |
| `/api/v1/products/:id` | `PUT` | Vendor, Admin | Update product stock, pricing, or description. |
| `/api/v1/products/:id` | `DELETE`| Vendor, Admin | Remove listing from marketplace. |
| `/api/v1/orders` | `POST` | Customer | Place a new order with cart items, delivery address, and payment method. |
| `/api/v1/orders/:id/status`| `PATCH`| Vendor, Admin | Transition order status (`Packed`, `Out for Delivery`, `Delivered`). |
| `/api/v1/gardeners` | `GET` | Public | Fetch list of verified gardeners, ratings, and open slots. |
| `/api/v1/bookings` | `POST` | Customer | Schedule a gardener appointment with date, slot, and garden type. |
| `/api/v1/bookings/:id/status`| `PATCH`| Gardener, Admin| Update booking status (`In Progress`, `Completed`, `Cancelled`). |
| `/api/v1/admin/approvals` | `POST` | Admin | Approve or reject vendor KYC registration applications. |
| `/api/v1/admin/disputes/:id`| `POST` | Admin | Resolve customer ticket with replacement guarantee note. |

---

## 9. Non-Functional Requirements & Performance

1. **Performance & Speed:**
   - Production bundle size under 110 kB gzipped JS and 11 kB CSS.
   - Time to Interactive (TTI) < 0.8 seconds on standard broadband.
   - First Contentful Paint (FCP) < 0.4 seconds.
2. **Reliability & Usability:**
   - High contrast accessibility (WCAG AA compliant) with distinct green and charcoal typography.
   - Mobile-first responsive breakpoints ensuring seamless operation on smartphones (360px+), tablets (768px+), and wide monitors (1440px+).
3. **Data Integrity:**
   - Automatic deduction of nursery stock upon customer checkout.
   - Client-side validation preventing booking past dates or negative product quantities.

---

## 10. Future Roadmap & Strategic Enhancements

- **Phase 2:**
  - Online Payment Gateway integrations (Razorpay, Stripe, Apple Pay).
  - Monthly plant subscription box ("Green Surprise Box").
  - Community forum for urban gardeners to exchange plant cuttings and tips.
- **Phase 3:**
  - AI Plant Disease Doctor: Upload leaf photo to diagnose fungal blight using computer vision.
  - IoT Soil Moisture Sensor sync via Bluetooth / Zigbee.
