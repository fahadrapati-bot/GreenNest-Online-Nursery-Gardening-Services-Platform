# 🌿 GreenNest – Online Nursery & Gardening Services Platform

> A centralized digital solution connecting plant lovers with verified local nurseries (Urbano Nursery) and certified professional gardeners on demand.

Developed for **Unified Mentor** & **Urbano Nursery** Project Requirements.

---

## 🚀 Instant Launch (Windows)

You have two simple ways to launch the platform:

### Method 1: Double-Click (Zero Terminal Commands)
1. Navigate to your Desktop folder: `GreenNest`
2. Double-click **`start.bat`**
3. It will automatically start the development server and launch your web browser to `http://localhost:5173`.

### Method 2: Terminal
```bash
cd C:\Users\fahad\OneDrive\Desktop\GreenNest
npm install
npm run dev
```

---

## 🌟 Key Features & Multi-Role Consoles

GreenNest includes a built-in **Live Role Switcher** in the top navigation bar so you can test all stakeholder flows seamlessly without needing manual account registration:

### 1. 👤 Customer Hub (Aarav Sharma)
- **Catalog & Shop:** Browse plants (indoor, outdoor, flowering), seeds, clay planters, and gardening tools.
- **Advanced Multi-Criteria Filters:** Filter by category, environment (indoor vs outdoor), price range, sunlight requirements, and search terms.
- **Plant Detail & Care Guide:** Full botanical specifications (sunlight, watering frequency, potting soil, temperature, pet safety).
- **Cart & Checkout:** Add items, apply discount code **`GREEN10`** (10% off) or **`URBANO20`** (20% off), select delivery slot, and place orders.
- **Book Verified Gardeners:** Schedule 2-hour home gardening visits with background-checked pros (Rajesh Kumar, Sunita Sharma).
- **My Orders & Bookings:** Visual 4-stage delivery tracker (`Placed` → `Packed` → `Out for Delivery` → `Delivered`), service visit scheduler, custom plant care reminders, and wishlist.
- **Plant Match Quiz:** 3-question interactive guide to find your ideal botanical companion.

### 2. 🏡 Nursery Vendor Console (Urbano Nursery)
- **Catalog Management:** Add new plants/supplies with photos, prices, and stock; inline edit prices; delete items.
- **Order Dispatch Queue:** View incoming customer orders and advance fulfillment status.
- **Payouts & Earnings:** Automated 10% platform commission breakdown and net nursery earnings report.

### 3. 👨‍🌾 Gardener Pro Schedule (Rajesh Kumar)
- **Availability Toggle:** Switch between `Available Today` and `Off-Duty`.
- **Scheduled Visits:** View customer details, garden notes, and appointment slots.
- **Service Progression:** Accept visits, mark `In Progress`, and complete jobs with earnings logged.

### 4. ⚙️ Platform Admin Operations (Unified Mentor)
- **Marketplace KPIs:** GMV, conversion rates, and fulfillment metrics.
- **KYC Approvals Queue:** Approve or reject pending nursery and gardener verification applications.
- **Catalog Oversight:** Global product moderation and de-listing.
- **Disputes Center:** Review customer tickets and resolve with replacement guarantees.

---

## 📁 Project Directory Structure

```
GreenNest/
├── PRD_GreenNest.md        # Comprehensive Product Requirements Document & Architecture
├── README.md               # Quick start & documentation
├── start.bat               # 1-click Windows Dev Launcher
├── preview.bat             # 1-click Windows Production Preview Launcher
├── package.json            # Dependencies (React 19, Tailwind CSS v4, Lucide Icons, Vite 8)
├── vite.config.js          # Vite configuration with Tailwind CSS v4 plugin
├── index.html              # HTML entry point with botanical branding
├── dist/                   # Production-ready build
└── src/
    ├── main.jsx            # React root mount
    ├── App.jsx             # Main router & modal coordinator
    ├── index.css           # Tailwind CSS v4 imports & styling
    ├── context/
    │   └── AppContext.jsx  # State management with reactive LocalStorage sync
    ├── data/
    │   └── seedData.js     # Botanical catalog, gardeners, initial orders & bookings
    └── components/
        ├── Navbar.jsx
        ├── Footer.jsx
        ├── CartDrawer.jsx
        ├── CheckoutModal.jsx
        ├── ProductDetailModal.jsx
        ├── ServiceBookingModal.jsx
        ├── PlantQuizModal.jsx
        ├── AuthModal.jsx
        ├── customer/
        │   ├── CustomerHome.jsx
        │   ├── ProductCatalog.jsx
        │   ├── GardenerServices.jsx
        │   └── CustomerDashboard.jsx
        ├── vendor/
        │   └── NurseryDashboard.jsx
        ├── gardener/
        │   └── GardenerDashboard.jsx
        └── admin/
            └── AdminDashboard.jsx
```

---

## 🛠️ Built With

- **React 19**
- **Vite 8**
- **Tailwind CSS v4**
- **Lucide React Icons**
- **LocalStorage API** (Persistent changes across reloads)
