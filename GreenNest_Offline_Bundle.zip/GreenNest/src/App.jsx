import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { CartDrawer } from './components/CartDrawer';
import { CheckoutModal } from './components/CheckoutModal';
import { ProductDetailModal } from './components/ProductDetailModal';
import { ServiceBookingModal } from './components/ServiceBookingModal';
import { PlantQuizModal } from './components/PlantQuizModal';
import { AuthModal } from './components/AuthModal';

// Views
import { CustomerHome } from './components/customer/CustomerHome';
import { ProductCatalog } from './components/customer/ProductCatalog';
import { GardenerServices } from './components/customer/GardenerServices';
import { CustomerDashboard } from './components/customer/CustomerDashboard';
import { NurseryDashboard } from './components/vendor/NurseryDashboard';
import { GardenerDashboard } from './components/gardener/GardenerDashboard';
import { AdminDashboard } from './components/admin/AdminDashboard';

// Toast Notification
import { CheckCircle2, AlertCircle, Info, X } from 'lucide-react';

const ToastNotification = () => {
  const { toast } = useApp();
  if (!toast) return null;

  const isError = toast.type === 'error';
  const isInfo = toast.type === 'info';

  return (
    <div className="fixed bottom-6 right-6 z-50 animate-in fade-in slide-in-from-bottom-5 duration-300">
      <div
        className={`flex items-center space-x-3 px-4 py-3 rounded-2xl shadow-2xl text-xs font-bold border backdrop-blur-md ${
          isError
            ? 'bg-red-900/90 text-white border-red-700'
            : isInfo
            ? 'bg-blue-900/90 text-white border-blue-700'
            : 'bg-emerald-950/95 text-white border-emerald-700 shadow-emerald-950/30'
        }`}
      >
        {isError ? (
          <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
        ) : isInfo ? (
          <Info className="w-4 h-4 text-blue-400 shrink-0" />
        ) : (
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
        )}
        <span>{toast.message}</span>
      </div>
    </div>
  );
};

const MainContent = () => {
  const { currentRole, activeCustomerTab } = useApp();

  return (
    <main className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
      {/* Customer Mode Views */}
      {currentRole === 'customer' && (
        <div className="space-y-12">
          {activeCustomerTab === 'shop' && (
            <>
              <CustomerHome />
              <div id="catalog-section">
                <ProductCatalog />
              </div>
            </>
          )}

          {activeCustomerTab === 'services' && <GardenerServices />}

          {activeCustomerTab === 'orders' && <CustomerDashboard defaultTab="orders" />}

          {activeCustomerTab === 'bookings' && <CustomerDashboard defaultTab="bookings" />}

          {activeCustomerTab === 'care' && <CustomerDashboard defaultTab="reminders" />}
        </div>
      )}

      {/* Nursery Vendor Portal View */}
      {currentRole === 'vendor' && <NurseryDashboard />}

      {/* Gardener Pro Portal View */}
      {currentRole === 'gardener' && <GardenerDashboard />}

      {/* Admin Operations View */}
      {currentRole === 'admin' && <AdminDashboard />}
    </main>
  );
};

export function App() {
  return (
    <AppProvider>
      <div className="min-h-screen flex flex-col bg-[#f8faf7] text-[#1a2e1d] selection:bg-emerald-200">
        <Navbar />
        <div className="flex-1">
          <MainContent />
        </div>
        <Footer />

        {/* Global Modals & Drawers */}
        <CartDrawer />
        <CheckoutModal />
        <ProductDetailModal />
        <ServiceBookingModal />
        <PlantQuizModal />
        <AuthModal />
        <ToastNotification />
      </div>
    </AppProvider>
  );
}

export default App;
