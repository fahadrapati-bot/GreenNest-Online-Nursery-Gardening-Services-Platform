import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  INITIAL_PRODUCTS,
  INITIAL_GARDENERS,
  INITIAL_SERVICES,
  INITIAL_ORDERS,
  INITIAL_BOOKINGS,
  INITIAL_APPLICATIONS,
  INITIAL_DISPUTES,
  INITIAL_NOTIFICATIONS
} from '../data/seedData';

const AppContext = createContext();

export const AppProvider = ({ children }) => {
  // Local storage helper
  const getStored = (key, fallback) => {
    try {
      const item = localStorage.getItem(`greennest_${key}`);
      return item ? JSON.parse(item) : fallback;
    } catch {
      return fallback;
    }
  };

  const saveStored = (key, data) => {
    try {
      localStorage.setItem(`greennest_${key}`, JSON.stringify(data));
    } catch (e) {
      console.error('Storage error:', e);
    }
  };

  // Roles: 'customer' | 'vendor' | 'gardener' | 'admin'
  const [currentRole, setCurrentRole] = useState(() => getStored('role', 'customer'));
  
  // App State
  const [products, setProducts] = useState(() => getStored('products', INITIAL_PRODUCTS));
  const [gardeners, setGardeners] = useState(() => getStored('gardeners', INITIAL_GARDENERS));
  const [services] = useState(INITIAL_SERVICES);
  const [orders, setOrders] = useState(() => getStored('orders', INITIAL_ORDERS));
  const [bookings, setBookings] = useState(() => getStored('bookings', INITIAL_BOOKINGS));
  const [applications, setApplications] = useState(() => getStored('applications', INITIAL_APPLICATIONS));
  const [disputes, setDisputes] = useState(() => getStored('disputes', INITIAL_DISPUTES));
  const [notifications, setNotifications] = useState(() => getStored('notifications', INITIAL_NOTIFICATIONS));
  const [cart, setCart] = useState(() => getStored('cart', []));
  const [wishlist, setWishlist] = useState(() => getStored('wishlist', ['prod-1', 'prod-7']));
  const [appliedCoupon, setAppliedCoupon] = useState(() => getStored('coupon', { code: 'GREEN10', discountPercent: 10 }));

  // UI state
  const [activeCustomerTab, setActiveCustomerTab] = useState('shop'); // 'shop' | 'services' | 'care' | 'orders' | 'bookings'
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  
  // Modals
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [bookingService, setBookingService] = useState(null);
  const [isQuizOpen, setIsQuizOpen] = useState(false);
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [toast, setToast] = useState(null);

  // Sync to local storage on changes
  useEffect(() => saveStored('role', currentRole), [currentRole]);
  useEffect(() => saveStored('products', products), [products]);
  useEffect(() => saveStored('gardeners', gardeners), [gardeners]);
  useEffect(() => saveStored('orders', orders), [orders]);
  useEffect(() => saveStored('bookings', bookings), [bookings]);
  useEffect(() => saveStored('applications', applications), [applications]);
  useEffect(() => saveStored('disputes', disputes), [disputes]);
  useEffect(() => saveStored('notifications', notifications), [notifications]);
  useEffect(() => saveStored('cart', cart), [cart]);
  useEffect(() => saveStored('wishlist', wishlist), [wishlist]);
  useEffect(() => saveStored('coupon', appliedCoupon), [appliedCoupon]);

  // Toast Helper
  const showToast = (message, type = 'success') => {
    setToast({ message, type, id: Date.now() });
    setTimeout(() => setToast(null), 4000);
  };

  // Add Notification Helper
  const pushNotification = (title, message, type = 'general') => {
    const newNotif = {
      id: `notif-${Date.now()}`,
      title,
      message,
      time: 'Just now',
      isRead: false,
      type
    };
    setNotifications(prev => [newNotif, ...prev]);
  };

  const markAllNotificationsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, isRead: true })));
    showToast('All notifications marked as read', 'info');
  };

  // Cart Management
  const addToCart = (product, quantity = 1) => {
    setCart(prev => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) {
        return prev.map(item =>
          item.id === product.id
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      }
      return [...prev, { ...product, quantity }];
    });
    showToast(`Added "${product.name}" to cart! 🌿`);
  };

  const updateCartQuantity = (productId, newQuantity) => {
    if (newQuantity <= 0) {
      removeFromCart(productId);
      return;
    }
    setCart(prev =>
      prev.map(item => (item.id === productId ? { ...item, quantity: newQuantity } : item))
    );
  };

  const removeFromCart = (productId) => {
    setCart(prev => prev.filter(item => item.id !== productId));
    showToast('Item removed from cart', 'info');
  };

  const clearCart = () => {
    setCart([]);
  };

  const applyDiscountCode = (code) => {
    const upper = code.trim().toUpperCase();
    if (upper === 'GREEN10') {
      setAppliedCoupon({ code: 'GREEN10', discountPercent: 10 });
      showToast('10% Green Care discount applied!', 'success');
      return true;
    } else if (upper === 'URBANO20') {
      setAppliedCoupon({ code: 'URBANO20', discountPercent: 20 });
      showToast('20% Urbano Nursery special promo applied!', 'success');
      return true;
    } else {
      showToast('Invalid coupon code. Try GREEN10', 'error');
      return false;
    }
  };

  // Wishlist
  const toggleWishlist = (productId) => {
    setWishlist(prev => {
      const exists = prev.includes(productId);
      if (exists) {
        showToast('Removed from wishlist');
        return prev.filter(id => id !== productId);
      } else {
        showToast('Added to wishlist ❤️');
        return [...prev, productId];
      }
    });
  };

  // Order Placement
  const placeOrder = (orderData) => {
    const newOrder = {
      id: `ORD-${Math.floor(10000 + Math.random() * 90000)}`,
      date: new Date().toISOString(),
      customerName: orderData.name || 'Aarav Sharma',
      customerEmail: orderData.email || 'aarav.sharma@example.com',
      customerPhone: orderData.phone || '+91 98765 43210',
      address: orderData.address,
      items: cart,
      subtotal: orderData.subtotal,
      discount: orderData.discount,
      packagingFee: orderData.packagingFee,
      deliveryFee: orderData.deliveryFee,
      total: orderData.total,
      status: 'Placed',
      paymentMethod: orderData.paymentMethod || 'UPI / Online Card',
      trackingNumber: `GN-EXP-${Math.floor(100000 + Math.random() * 900000)}`,
      estimatedDelivery: 'Tomorrow by 4:00 PM'
    };

    // Deduct stock
    setProducts(prev =>
      prev.map(p => {
        const bought = cart.find(c => c.id === p.id);
        if (bought) {
          return { ...p, stock: Math.max(0, p.stock - bought.quantity) };
        }
        return p;
      })
    );

    setOrders(prev => [newOrder, ...prev]);
    clearCart();
    setIsCheckoutOpen(false);
    showToast(`Order #${newOrder.id} placed successfully! 📦`, 'success');
    pushNotification('Order Confirmed! 🎉', `Order #${newOrder.id} has been received and sent to nursery.`, 'order');
    return newOrder;
  };

  // Vendor order status update
  const updateOrderStatus = (orderId, newStatus) => {
    setOrders(prev =>
      prev.map(ord => (ord.id === orderId ? { ...ord, status: newStatus } : ord))
    );
    showToast(`Order ${orderId} marked as "${newStatus}"`, 'success');
    pushNotification(
      `Order ${orderId} Status Updated`,
      `Your order is now: ${newStatus}`,
      'order'
    );
  };

  // Service Booking
  const createBooking = (bookingData) => {
    const newBooking = {
      id: `BKG-${Math.floor(1000 + Math.random() * 9000)}`,
      serviceId: bookingData.serviceId,
      serviceName: bookingData.serviceName,
      gardenerId: bookingData.gardenerId,
      gardenerName: bookingData.gardenerName,
      gardenerPhone: bookingData.gardenerPhone || '+91 98450 11223',
      customerName: bookingData.name || 'Aarav Sharma',
      customerEmail: bookingData.email || 'aarav.sharma@example.com',
      customerPhone: bookingData.phone || '+91 98765 43210',
      address: bookingData.address,
      gardenType: bookingData.gardenType,
      date: bookingData.date,
      timeSlot: bookingData.timeSlot,
      price: bookingData.price,
      status: 'Confirmed',
      notes: bookingData.notes || '',
      paymentStatus: 'Paid Online'
    };

    setBookings(prev => [newBooking, ...prev]);
    setBookingService(null);
    showToast(`Gardener booking #${newBooking.id} confirmed! 👨‍🌾`, 'success');
    pushNotification(
      'Service Booking Confirmed! 🌱',
      `${newBooking.gardenerName} is scheduled for ${newBooking.date} at ${newBooking.timeSlot}.`,
      'booking'
    );
    return newBooking;
  };

  const updateBookingStatus = (bookingId, newStatus) => {
    setBookings(prev =>
      prev.map(b => (b.id === bookingId ? { ...b, status: newStatus } : b))
    );
    showToast(`Booking ${bookingId} updated to "${newStatus}"`, 'success');
    pushNotification(
      `Service Booking ${bookingId} Update`,
      `Your service appointment is now: ${newStatus}`,
      'booking'
    );
  };

  // Product CRUD (For Vendor & Admin)
  const addProduct = (productData) => {
    const newProd = {
      ...productData,
      id: `prod-${Date.now()}`,
      rating: 5.0,
      reviewsCount: 1,
      stock: Number(productData.stock) || 10,
      price: Number(productData.price) || 19.99,
      originalPrice: Number(productData.price) * 1.25,
      nurseryId: currentRole === 'vendor' ? 'nursery-1' : 'nursery-admin',
      nurseryName: currentRole === 'vendor' ? 'Urbano Nursery' : 'GreenNest Direct'
    };
    setProducts(prev => [newProd, ...prev]);
    showToast(`Product "${newProd.name}" listed successfully! 🌿`, 'success');
  };

  const updateProduct = (id, updatedFields) => {
    setProducts(prev =>
      prev.map(p => (p.id === id ? { ...p, ...updatedFields } : p))
    );
    showToast('Product updated successfully!', 'success');
  };

  const deleteProduct = (id) => {
    setProducts(prev => prev.filter(p => p.id !== id));
    showToast('Product removed from catalog', 'info');
  };

  // Gardener Availability
  const toggleGardenerStatus = (gardenerId) => {
    setGardeners(prev =>
      prev.map(g =>
        g.id === gardenerId
          ? {
              ...g,
              status: g.status === 'Available Today' ? 'Off Duty' : 'Available Today'
            }
          : g
      )
    );
    showToast('Gardener availability status updated!');
  };

  // Admin Approvals
  const reviewApplication = (appId, newStatus) => {
    setApplications(prev =>
      prev.map(a => (a.id === appId ? { ...a, status: newStatus } : a))
    );
    showToast(`Application #${appId} marked as ${newStatus}!`, 'success');
  };

  // Dispute Resolution
  const resolveDispute = (disputeId, note) => {
    setDisputes(prev =>
      prev.map(d =>
        d.id === disputeId
          ? { ...d, status: 'Resolved', resolutionNote: note || 'Resolved by Admin' }
          : d
      )
    );
    showToast(`Dispute #${disputeId} marked as resolved!`, 'success');
  };

  // Reset to seed data
  const resetAllData = () => {
    localStorage.clear();
    setProducts(INITIAL_PRODUCTS);
    setGardeners(INITIAL_GARDENERS);
    setOrders(INITIAL_ORDERS);
    setBookings(INITIAL_BOOKINGS);
    setApplications(INITIAL_APPLICATIONS);
    setDisputes(INITIAL_DISPUTES);
    setNotifications(INITIAL_NOTIFICATIONS);
    setCart([]);
    setWishlist(['prod-1', 'prod-7']);
    setAppliedCoupon({ code: 'GREEN10', discountPercent: 10 });
    setCurrentRole('customer');
    showToast('Demo data reset to original defaults! 🍃', 'info');
  };

  return (
    <AppContext.Provider
      value={{
        // Role & Auth
        currentRole,
        setCurrentRole,
        // State
        products,
        gardeners,
        services,
        orders,
        bookings,
        applications,
        disputes,
        notifications,
        cart,
        wishlist,
        appliedCoupon,
        // Customer Filters
        activeCustomerTab,
        setActiveCustomerTab,
        searchQuery,
        setSearchQuery,
        selectedCategory,
        setSelectedCategory,
        // Cart ops
        addToCart,
        updateCartQuantity,
        removeFromCart,
        clearCart,
        applyDiscountCode,
        // Wishlist ops
        toggleWishlist,
        // Order ops
        placeOrder,
        updateOrderStatus,
        // Booking ops
        createBooking,
        updateBookingStatus,
        // Product ops
        addProduct,
        updateProduct,
        deleteProduct,
        // Gardener ops
        toggleGardenerStatus,
        // Admin ops
        reviewApplication,
        resolveDispute,
        // Notification ops
        markAllNotificationsRead,
        pushNotification,
        // Modals & Popups
        isCartOpen,
        setIsCartOpen,
        isCheckoutOpen,
        setIsCheckoutOpen,
        selectedProduct,
        setSelectedProduct,
        bookingService,
        setBookingService,
        isQuizOpen,
        setIsQuizOpen,
        isAuthOpen,
        setIsAuthOpen,
        toast,
        showToast,
        resetAllData
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within an AppProvider');
  return context;
};
