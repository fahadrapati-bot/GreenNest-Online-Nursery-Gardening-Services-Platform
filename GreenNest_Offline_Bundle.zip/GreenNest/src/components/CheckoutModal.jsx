import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  X,
  MapPin,
  Clock,
  CreditCard,
  CheckCircle,
  Truck,
  ShieldCheck,
  ArrowRight,
  PackageCheck
} from 'lucide-react';

export const CheckoutModal = () => {
  const {
    isCheckoutOpen,
    setIsCheckoutOpen,
    cart,
    appliedCoupon,
    placeOrder,
    setActiveCustomerTab
  } = useApp();

  const [formData, setFormData] = useState({
    name: 'Aarav Sharma',
    email: 'aarav.sharma@example.com',
    phone: '+91 98765 43210',
    address: 'Flat 402, Green Meadows Residency, 12th Main Road, Indiranagar',
    city: 'Bengaluru',
    pincode: '560038',
    deliverySlot: 'Tomorrow Morning (9 AM - 1 PM)',
    paymentMethod: 'UPI / Online Instant',
    instructions: 'Please call before arrival. Deliver in shade if sunny.'
  });

  const [confirmedOrder, setConfirmedOrder] = useState(null);

  if (!isCheckoutOpen) return null;

  const subtotal = cart.reduce((acc, item) => acc + item.price * item.quantity, 0);
  const discount = appliedCoupon ? (subtotal * appliedCoupon.discountPercent) / 100 : 0;
  const packagingFee = 2.00;
  const deliveryFee = subtotal > 50 ? 0.00 : 4.99;
  const grandTotal = Math.max(0, subtotal - discount + packagingFee + deliveryFee);

  const handleSubmit = (e) => {
    e.preventDefault();
    const order = placeOrder({
      ...formData,
      subtotal,
      discount,
      packagingFee,
      deliveryFee,
      total: grandTotal
    });
    setConfirmedOrder(order);
  };

  const handleClose = () => {
    setConfirmedOrder(null);
    setIsCheckoutOpen(false);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-2xl w-full shadow-2xl overflow-hidden border border-gray-100 my-8">
        {/* Order Confirmed View */}
        {confirmedOrder ? (
          <div className="p-8 text-center space-y-5">
            <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto ring-8 ring-emerald-50 animate-bounce">
              <PackageCheck className="w-8 h-8" />
            </div>

            <div>
              <span className="text-xs font-bold uppercase tracking-widest text-emerald-700 bg-emerald-100/60 px-3 py-1 rounded-full">
                Order Confirmed
              </span>
              <h2 className="text-2xl font-black text-gray-900 mt-2">
                Thank You for Choosing GreenNest!
              </h2>
              <p className="text-xs text-gray-600 mt-1 max-w-md mx-auto">
                Your plant package is being carefully prepared by our verified nursery partners with specialized moisture seals.
              </p>
            </div>

            <div className="bg-emerald-50/70 border border-emerald-100 rounded-2xl p-4 text-left space-y-2 text-xs">
              <div className="flex justify-between border-b border-emerald-200/50 pb-2">
                <span className="text-gray-500">Order ID:</span>
                <span className="font-bold text-gray-900">{confirmedOrder.id}</span>
              </div>
              <div className="flex justify-between border-b border-emerald-200/50 pb-2">
                <span className="text-gray-500">Tracking Code:</span>
                <span className="font-mono font-bold text-emerald-800">{confirmedOrder.trackingNumber}</span>
              </div>
              <div className="flex justify-between border-b border-emerald-200/50 pb-2">
                <span className="text-gray-500">Estimated Delivery:</span>
                <span className="font-bold text-gray-900">{confirmedOrder.estimatedDelivery}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">Total Paid:</span>
                <span className="font-black text-emerald-700 text-sm">${confirmedOrder.total.toFixed(2)}</span>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-3 pt-2">
              <button
                onClick={() => {
                  handleClose();
                  setActiveCustomerTab('orders');
                }}
                className="flex-1 bg-emerald-700 hover:bg-emerald-800 text-white font-bold py-3 px-4 rounded-xl text-xs transition flex items-center justify-center space-x-1.5 shadow-md shadow-emerald-700/20"
              >
                <span>Track Order in My Orders</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={handleClose}
                className="bg-gray-100 hover:bg-gray-200 text-gray-700 font-bold py-3 px-4 rounded-xl text-xs transition"
              >
                Continue Browsing
              </button>
            </div>
          </div>
        ) : (
          /* Checkout Form */
          <div>
            {/* Modal Header */}
            <div className="p-5 border-b border-gray-100 flex items-center justify-between bg-emerald-900 text-white">
              <div className="flex items-center space-x-2.5">
                <div className="p-2 rounded-xl bg-emerald-800">
                  <Truck className="w-5 h-5 text-emerald-300" />
                </div>
                <div>
                  <h3 className="font-bold text-base">Secure Plant Checkout</h3>
                  <p className="text-xs text-emerald-200">Safe doorstep delivery from local nurseries</p>
                </div>
              </div>
              <button
                onClick={handleClose}
                className="p-1 rounded-lg text-emerald-200 hover:text-white hover:bg-emerald-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-5">
              {/* Delivery Details */}
              <div className="space-y-3">
                <h4 className="text-xs font-bold text-gray-900 uppercase tracking-wider flex items-center space-x-1.5">
                  <MapPin className="w-4 h-4 text-emerald-600" />
                  <span>Delivery Address</span>
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div>
                    <label className="block text-gray-600 mb-1 font-medium">Recipient Name</label>
                    <input
                      type="text"
                      required
                      value={formData.name}
                      onChange={e => setFormData({ ...formData, name: e.target.value })}
                      className="w-full p-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:bg-white focus:border-emerald-500 focus:outline-hidden"
                    />
                  </div>

                  <div>
                    <label className="block text-gray-600 mb-1 font-medium">Contact Phone</label>
                    <input
                      type="tel"
                      required
                      value={formData.phone}
                      onChange={e => setFormData({ ...formData, phone: e.target.value })}
                      className="w-full p-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:bg-white focus:border-emerald-500 focus:outline-hidden"
                    />
                  </div>
                </div>

                <div className="text-xs">
                  <label className="block text-gray-600 mb-1 font-medium">Complete Street Address</label>
                  <input
                    type="text"
                    required
                    value={formData.address}
                    onChange={e => setFormData({ ...formData, address: e.target.value })}
                    className="w-full p-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:bg-white focus:border-emerald-500 focus:outline-hidden"
                  />
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
                  <div>
                    <label className="block text-gray-600 mb-1 font-medium">City</label>
                    <input
                      type="text"
                      required
                      value={formData.city}
                      onChange={e => setFormData({ ...formData, city: e.target.value })}
                      className="w-full p-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:bg-white focus:border-emerald-500 focus:outline-hidden"
                    />
                  </div>

                  <div>
                    <label className="block text-gray-600 mb-1 font-medium">Pincode</label>
                    <input
                      type="text"
                      required
                      value={formData.pincode}
                      onChange={e => setFormData({ ...formData, pincode: e.target.value })}
                      className="w-full p-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:bg-white focus:border-emerald-500 focus:outline-hidden"
                    />
                  </div>

                  <div className="col-span-2 sm:col-span-1">
                    <label className="block text-gray-600 mb-1 font-medium">Delivery Slot</label>
                    <select
                      value={formData.deliverySlot}
                      onChange={e => setFormData({ ...formData, deliverySlot: e.target.value })}
                      className="w-full p-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:bg-white focus:border-emerald-500 focus:outline-hidden"
                    >
                      <option>Tomorrow Morning (9 AM - 1 PM)</option>
                      <option>Tomorrow Afternoon (1 PM - 5 PM)</option>
                      <option>Tomorrow Evening (5 PM - 8 PM)</option>
                      <option>Day After Tomorrow</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Payment Mode Selection */}
              <div className="space-y-3 pt-2">
                <h4 className="text-xs font-bold text-gray-900 uppercase tracking-wider flex items-center space-x-1.5">
                  <CreditCard className="w-4 h-4 text-emerald-600" />
                  <span>Payment Method</span>
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-xs">
                  {[
                    { id: 'UPI / Online Instant', label: 'UPI / QR Code', sub: 'Instant Zero-Fee' },
                    { id: 'Credit / Debit Card', label: 'Cards / NetBanking', sub: 'Visa, Master, RuPay' },
                    { id: 'Cash on Delivery', label: 'Cash on Delivery', sub: 'Pay on plant arrival' }
                  ].map(method => (
                    <label
                      key={method.id}
                      className={`flex flex-col p-3 rounded-xl border cursor-pointer transition ${
                        formData.paymentMethod === method.id
                          ? 'border-emerald-600 bg-emerald-50/60 font-semibold text-emerald-950 ring-1 ring-emerald-600'
                          : 'border-gray-200 hover:border-gray-300 bg-white'
                      }`}
                    >
                      <div className="flex items-center space-x-2">
                        <input
                          type="radio"
                          name="payment"
                          value={method.id}
                          checked={formData.paymentMethod === method.id}
                          onChange={e => setFormData({ ...formData, paymentMethod: e.target.value })}
                          className="text-emerald-600 focus:ring-emerald-500"
                        />
                        <span className="text-xs">{method.label}</span>
                      </div>
                      <span className="text-[10px] text-gray-500 mt-1 pl-5">{method.sub}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Order Summary Box */}
              <div className="bg-gray-50 rounded-2xl p-4 space-y-2 text-xs border border-gray-200">
                <div className="flex justify-between text-gray-600">
                  <span>Items Total ({cart.length} unique)</span>
                  <span className="font-semibold text-gray-800">${subtotal.toFixed(2)}</span>
                </div>
                {appliedCoupon && (
                  <div className="flex justify-between text-emerald-700 font-medium">
                    <span>Coupon ({appliedCoupon.code})</span>
                    <span>-${discount.toFixed(2)}</span>
                  </div>
                )}
                <div className="flex justify-between text-gray-600">
                  <span>Biodegradable Eco-Packaging</span>
                  <span className="font-semibold text-gray-800">${packagingFee.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-gray-600">
                  <span>Shipping</span>
                  <span className="font-semibold text-gray-800">{deliveryFee === 0 ? 'FREE' : `$${deliveryFee.toFixed(2)}`}</span>
                </div>
                <div className="border-t border-gray-200 pt-2 flex justify-between font-black text-sm text-gray-900">
                  <span>Total Payable</span>
                  <span className="text-emerald-700 text-base">${grandTotal.toFixed(2)}</span>
                </div>
              </div>

              {/* Guarantee */}
              <div className="flex items-center space-x-2 text-[11px] text-gray-500">
                <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Protected by GreenNest 7-Day Plant Health Replacement Guarantee.</span>
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                className="w-full bg-emerald-700 hover:bg-emerald-800 text-white font-bold py-3.5 px-4 rounded-xl shadow-lg shadow-emerald-700/25 flex items-center justify-center space-x-2 text-sm transition"
              >
                <span>Place Order (${grandTotal.toFixed(2)})</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          </div>
        )}
      </div>
    </div>
  );
};
