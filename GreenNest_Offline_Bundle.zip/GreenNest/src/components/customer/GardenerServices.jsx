import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  Calendar,
  CheckCircle2,
  Star,
  ShieldCheck,
  Award,
  Clock,
  ArrowRight,
  Leaf,
  Sun,
  Compass,
  PhoneCall,
  UserCheck
} from 'lucide-react';

export const GardenerServices = () => {
  const { services, gardeners, setBookingService } = useApp();

  return (
    <div className="space-y-12">
      {/* Banner */}
      <div className="bg-gradient-to-r from-emerald-900 to-teal-950 text-white rounded-3xl p-8 sm:p-12 shadow-xl relative overflow-hidden">
        <div className="relative z-10 max-w-2xl space-y-4">
          <div className="inline-flex items-center space-x-2 bg-emerald-800/80 px-3 py-1 rounded-full text-xs font-semibold text-emerald-200 border border-emerald-700/50">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>100% Background Checked & Certified Horticulturalists</span>
          </div>
          <h1 className="text-2xl sm:text-4xl font-black tracking-tight leading-tight">
            Verified Gardeners & Plant Care Specialists at Your Doorstep.
          </h1>
          <p className="text-xs sm:text-sm text-emerald-100/80 leading-relaxed">
            From balcony plant trimming to full lawn mowing and organic pest eradication. Book standard, reliable gardening services with transparent fixed rates and zero hidden charges.
          </p>
        </div>

        {/* Floating Accent Shapes */}
        <div className="absolute right-0 top-0 bottom-0 w-1/3 bg-emerald-800/20 rounded-l-full pointer-events-none" />
      </div>

      {/* Services List */}
      <section className="space-y-6">
        <div>
          <h2 className="text-xl font-black text-gray-900">Choose a Gardening Service Package</h2>
          <p className="text-xs text-gray-500 mt-0.5">Fixed rates including gardener labor, equipment & bio-fertilizer</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {services.map(serv => (
            <div
              key={serv.id}
              className="bg-white rounded-3xl p-6 sm:p-7 border border-gray-100 hover:border-emerald-300 shadow-2xs hover:shadow-xl transition flex flex-col justify-between space-y-6 group"
            >
              <div className="space-y-4">
                <div className="flex items-start justify-between">
                  <div className="p-3 rounded-2xl bg-emerald-50 text-emerald-700 border border-emerald-100">
                    <Leaf className="w-6 h-6" />
                  </div>
                  <div className="text-right">
                    <span className="text-2xl font-black text-emerald-800">${serv.price.toFixed(2)}</span>
                    <span className="block text-[11px] text-gray-400">per visit ({serv.duration})</span>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-black text-gray-900 group-hover:text-emerald-800 transition">
                    {serv.name}
                  </h3>
                  <p className="text-xs text-gray-500 mt-1">{serv.tagline}</p>
                </div>

                <div className="pt-2 border-t border-gray-100 space-y-2">
                  <span className="text-[11px] font-bold text-gray-700 uppercase tracking-wider block">
                    What's Included in This Package:
                  </span>
                  <ul className="space-y-1.5 text-xs text-gray-600">
                    {serv.includes.map((inc, i) => (
                      <li key={i} className="flex items-start space-x-2">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                        <span>{inc}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              <div className="pt-4 border-t border-gray-100 flex items-center justify-between">
                <div className="flex items-center space-x-1.5 text-xs text-emerald-700 font-semibold">
                  <Clock className="w-3.5 h-3.5" />
                  <span>Duration: {serv.duration}</span>
                </div>

                <button
                  onClick={() => setBookingService(serv)}
                  className="bg-emerald-700 hover:bg-emerald-800 text-white font-bold py-2.5 px-5 rounded-xl text-xs transition flex items-center space-x-1.5 shadow-md shadow-emerald-700/20"
                >
                  <span>Book Service Now</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Verified Gardeners Directory */}
      <section className="space-y-6">
        <div>
          <h2 className="text-xl font-black text-gray-900">Meet Our Verified Gardener Partners</h2>
          <p className="text-xs text-gray-500 mt-0.5">Experienced horticulturists vetted for professionalism and plant care skill</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {gardeners.map(gardener => (
            <div
              key={gardener.id}
              className="bg-white rounded-3xl p-6 border border-gray-100 hover:border-emerald-200 shadow-2xs hover:shadow-lg transition flex flex-col justify-between space-y-4"
            >
              <div className="space-y-3">
                <div className="flex items-center space-x-3">
                  <img
                    src={gardener.image}
                    alt={gardener.name}
                    className="w-16 h-16 rounded-2xl object-cover border-2 border-emerald-100 shadow-xs"
                  />
                  <div>
                    <div className="flex items-center space-x-1">
                      <h3 className="font-bold text-gray-900 text-sm">{gardener.name}</h3>
                      <ShieldCheck className="w-4 h-4 text-emerald-600" />
                    </div>
                    <p className="text-[11px] text-emerald-700 font-medium">{gardener.title}</p>
                    <div className="flex items-center space-x-1 text-amber-500 font-bold text-xs mt-0.5">
                      <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                      <span>{gardener.rating}</span>
                      <span className="text-gray-400 font-normal">({gardener.reviewsCount} reviews)</span>
                    </div>
                  </div>
                </div>

                <p className="text-xs text-gray-600 leading-relaxed">{gardener.bio}</p>

                {/* Specialties */}
                <div>
                  <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block mb-1.5">
                    Specialties:
                  </span>
                  <div className="flex flex-wrap gap-1">
                    {gardener.specialties.map((spec, idx) => (
                      <span
                        key={idx}
                        className="bg-emerald-50 text-emerald-800 text-[10px] font-semibold px-2 py-0.5 rounded-md"
                      >
                        {spec}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              <div className="pt-3 border-t border-gray-100 flex items-center justify-between">
                <div>
                  <span className="text-xs text-gray-400 block">Rate</span>
                  <span className="text-sm font-black text-gray-900">${gardener.hourlyRate}/hr</span>
                </div>

                <button
                  onClick={() => setBookingService(services[0])}
                  className="bg-emerald-50 hover:bg-emerald-100 text-emerald-800 font-bold py-2 px-3.5 rounded-xl text-xs transition flex items-center space-x-1 border border-emerald-200"
                >
                  <Calendar className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Book Visit</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};
