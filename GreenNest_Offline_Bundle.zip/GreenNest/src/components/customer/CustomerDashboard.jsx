import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Package,
  Calendar,
  Clock,
  MapPin,
  CheckCircle2,
  Circle,
  Truck,
  Heart,
  Droplets,
  Sun,
  AlertCircle,
  ArrowRight,
  Phone,
  ShieldCheck,
  RotateCcw,
  Check
} from 'lucide-react';

export const CustomerDashboard = ({ defaultTab = 'orders' }) => {
  const {
    orders,
    bookings,
    updateOrderStatus,
    updateBookingStatus,
    products,
    wishlist,
    toggleWishlist,
    addToCart,
    showToast
  } = useApp();

  const [activeTab, setActiveTab] = useState(defaultTab);

  // Sample Interactive Plant Care Reminders
  const [reminders, setReminders] = useState([
    { id: 1, plant: 'Monstera Deliciosa', task: 'Check top 2-inches soil moisture and water if dry', due: 'Today', done: false, icon: Droplets },
    { id: 2, plant: 'Peace Lily', task: 'Wipe dust off broad foliage with damp microfiber cloth', due: 'Tomorrow', done: false, icon: Sun },
    { id: 3, plant: 'Snake Plant', task: 'Add 1 spoon organic vermicompost to potting rim', due: 'This Weekend', done: true, icon: CheckCircle2 }
  ]);

  const toggleReminder = (id) => {
    setReminders(prev =>
      prev.map(r => (r.id === id ? { ...r, done: !r.done } : r))
    );
    showToast('Plant care checklist updated! 🌿');
  };

  const wishlistedProducts = products.filter(p => wishlist.includes(p.id));

  const stages = ['Placed', 'Packed', 'Out for Delivery', 'Delivered'];

  const getStageIndex = (status) => {
    const idx = stages.indexOf(status);
    return idx === -1 ? 0 : idx;
  };

  return (
    <div className="space-y-6">
      {/* Dashboard Top Banner */}
      <div className="bg-white rounded-3xl p-6 border border-emerald-100 shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center space-x-3">
          <div className="w-12 h-12 rounded-2xl bg-emerald-700 text-white font-black text-lg flex items-center justify-center shadow-md">
            AS
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h1 className="text-xl font-black text-gray-900">Aarav Sharma</h1>
              <span className="text-[10px] font-bold bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full">
                Green Member
              </span>
            </div>
            <p className="text-xs text-gray-500">aarav.sharma@example.com • Indiranagar, Bengaluru</p>
          </div>
        </div>

        {/* Tab Controls */}
        <div className="flex bg-gray-100 p-1 rounded-2xl text-xs font-bold w-full sm:w-auto overflow-x-auto">
          <button
            onClick={() => setActiveTab('orders')}
            className={`px-4 py-2 rounded-xl transition flex items-center space-x-1.5 whitespace-nowrap ${
              activeTab === 'orders' ? 'bg-white text-emerald-950 shadow-xs' : 'text-gray-600'
            }`}
          >
            <Package className="w-3.5 h-3.5" />
            <span>My Orders ({orders.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('bookings')}
            className={`px-4 py-2 rounded-xl transition flex items-center space-x-1.5 whitespace-nowrap ${
              activeTab === 'bookings' ? 'bg-white text-emerald-950 shadow-xs' : 'text-gray-600'
            }`}
          >
            <Calendar className="w-3.5 h-3.5" />
            <span>Gardener Visits ({bookings.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('reminders')}
            className={`px-4 py-2 rounded-xl transition flex items-center space-x-1.5 whitespace-nowrap ${
              activeTab === 'reminders' ? 'bg-white text-emerald-950 shadow-xs' : 'text-gray-600'
            }`}
          >
            <Droplets className="w-3.5 h-3.5" />
            <span>Plant Care Reminders</span>
          </button>

          <button
            onClick={() => setActiveTab('wishlist')}
            className={`px-4 py-2 rounded-xl transition flex items-center space-x-1.5 whitespace-nowrap ${
              activeTab === 'wishlist' ? 'bg-white text-emerald-950 shadow-xs' : 'text-gray-600'
            }`}
          >
            <Heart className="w-3.5 h-3.5" />
            <span>Wishlist ({wishlist.length})</span>
          </button>
        </div>
      </div>

      {/* Orders Tab */}
      {activeTab === 'orders' && (
        <div className="space-y-4">
          {orders.length === 0 ? (
            <div className="bg-white rounded-3xl p-12 text-center border border-gray-100">
              <Package className="w-12 h-12 text-gray-300 mx-auto mb-3" />
              <h3 className="font-bold text-gray-800 text-sm">No plant orders placed yet</h3>
              <p className="text-xs text-gray-500 mt-1">Browse our nursery catalog to order fresh potted foliage.</p>
            </div>
          ) : (
            orders.map(order => {
              const currentStageIdx = getStageIndex(order.status);

              return (
                <div
                  key={order.id}
                  className="bg-white rounded-3xl p-6 border border-gray-100 shadow-2xs space-y-6"
                >
                  {/* Order Top Line */}
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-gray-100 gap-2">
                    <div>
                      <div className="flex items-center space-x-2">
                        <span className="font-black text-sm text-gray-900">{order.id}</span>
                        <span className="text-[11px] font-mono text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                          {order.trackingNumber}
                        </span>
                      </div>
                      <p className="text-[11px] text-gray-400 mt-0.5">
                        Placed on {new Date(order.date).toLocaleDateString()} • {order.paymentMethod}
                      </p>
                    </div>

                    <div className="flex items-center space-x-3">
                      <span className="text-sm font-black text-emerald-800">
                        Total: ${order.total.toFixed(2)}
                      </span>
                      {order.status === 'Placed' && (
                        <button
                          onClick={() => updateOrderStatus(order.id, 'Cancelled')}
                          className="text-xs text-red-600 hover:text-red-700 font-semibold border border-red-200 px-2.5 py-1 rounded-lg"
                        >
                          Cancel
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Visual Stepper Tracker */}
                  <div className="py-2">
                    <span className="text-[11px] font-bold text-gray-400 uppercase tracking-wider block mb-3">
                      Live Delivery Progress
                    </span>
                    <div className="grid grid-cols-4 gap-2 relative">
                      {stages.map((stage, idx) => {
                        const isDone = idx <= currentStageIdx;
                        const isCurrent = idx === currentStageIdx;

                        return (
                          <div key={stage} className="text-center">
                            <div className="flex items-center justify-center mb-1.5">
                              <div
                                className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition shadow-xs ${
                                  isDone
                                    ? 'bg-emerald-600 text-white ring-4 ring-emerald-100'
                                    : 'bg-gray-100 text-gray-400'
                                }`}
                              >
                                {isDone ? <Check className="w-4 h-4" /> : idx + 1}
                              </div>
                            </div>
                            <span
                              className={`text-[11px] font-bold block ${
                                isCurrent
                                  ? 'text-emerald-900'
                                  : isDone
                                  ? 'text-gray-700'
                                  : 'text-gray-400'
                              }`}
                            >
                              {stage}
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* Order Items & Shipping Address */}
                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 pt-2 border-t border-gray-100 text-xs">
                    {/* Items */}
                    <div className="lg:col-span-2 space-y-2">
                      <span className="font-bold text-gray-700 block">Ordered Items:</span>
                      <div className="space-y-2">
                        {order.items.map((item, idx) => (
                          <div key={idx} className="flex items-center space-x-3 bg-gray-50/70 p-2 rounded-xl">
                            <img
                              src={item.image}
                              alt={item.name}
                              className="w-12 h-12 rounded-lg object-cover"
                            />
                            <div className="flex-1 min-w-0">
                              <h4 className="font-bold text-gray-900 text-xs truncate">{item.name}</h4>
                              <p className="text-[11px] text-emerald-700">From {item.nurseryName}</p>
                            </div>
                            <div className="text-right">
                              <span className="font-bold text-gray-900">
                                ${(item.price * item.quantity).toFixed(2)}
                              </span>
                              <p className="text-[10px] text-gray-400">Qty: {item.quantity}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Shipping Address */}
                    <div className="bg-emerald-50/40 p-3.5 rounded-2xl border border-emerald-100 space-y-2">
                      <span className="font-bold text-emerald-950 block">Destination & Carrier</span>
                      <p className="text-gray-600 leading-relaxed text-[11px]">{order.address}</p>
                      <div className="pt-2 border-t border-emerald-100 flex items-center space-x-1.5 text-emerald-800 font-semibold">
                        <Truck className="w-3.5 h-3.5 text-emerald-600" />
                        <span>Est: {order.estimatedDelivery}</span>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      )}

      {/* Bookings Tab */}
      {activeTab === 'bookings' && (
        <div className="space-y-4">
          {bookings.length === 0 ? (
            <div className="bg-white rounded-3xl p-12 text-center border border-gray-100">
              <Calendar className="w-12 h-12 text-gray-300 mx-auto mb-3" />
              <h3 className="font-bold text-gray-800 text-sm">No gardener visits booked yet</h3>
              <p className="text-xs text-gray-500 mt-1">Book a certified gardener for home pruning, repotting, or lawn mowing.</p>
            </div>
          ) : (
            bookings.map(bkg => (
              <div
                key={bkg.id}
                className="bg-white rounded-3xl p-6 border border-gray-100 shadow-2xs space-y-4"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-gray-100 gap-2">
                  <div>
                    <div className="flex items-center space-x-2">
                      <span className="font-black text-sm text-gray-900">{bkg.id}</span>
                      <span className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full ${
                        bkg.status === 'Confirmed'
                          ? 'bg-blue-100 text-blue-800'
                          : bkg.status === 'Completed'
                          ? 'bg-green-100 text-green-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}>
                        {bkg.status}
                      </span>
                    </div>
                    <h3 className="font-bold text-emerald-950 text-base mt-1">{bkg.serviceName}</h3>
                  </div>

                  <div className="text-right">
                    <span className="text-lg font-black text-emerald-800">${bkg.price.toFixed(2)}</span>
                    <span className="block text-[10px] text-gray-400">{bkg.paymentStatus}</span>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                  <div className="bg-gray-50 p-3 rounded-xl">
                    <span className="text-gray-400 block mb-0.5 font-medium">Assigned Gardener Pro</span>
                    <span className="font-bold text-gray-900 block">{bkg.gardenerName}</span>
                    <span className="text-[11px] text-emerald-700 flex items-center space-x-1 mt-0.5">
                      <Phone className="w-3 h-3" />
                      <span>{bkg.gardenerPhone}</span>
                    </span>
                  </div>

                  <div className="bg-gray-50 p-3 rounded-xl">
                    <span className="text-gray-400 block mb-0.5 font-medium">Appointment Schedule</span>
                    <span className="font-bold text-gray-900 block">{bkg.date}</span>
                    <span className="text-[11px] text-emerald-700 flex items-center space-x-1 mt-0.5">
                      <Clock className="w-3 h-3" />
                      <span>{bkg.timeSlot}</span>
                    </span>
                  </div>

                  <div className="bg-gray-50 p-3 rounded-xl">
                    <span className="text-gray-400 block mb-0.5 font-medium">Garden Setup</span>
                    <span className="font-bold text-gray-900 block truncate">{bkg.gardenType}</span>
                    <p className="text-[11px] text-gray-500 mt-0.5 truncate">{bkg.notes || 'No special requests'}</p>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-gray-100 text-xs">
                  <span className="text-gray-500 flex items-center space-x-1">
                    <ShieldCheck className="w-4 h-4 text-emerald-600" />
                    <span>Includes standard organic fertilizer & tool disinfection</span>
                  </span>

                  {bkg.status === 'Confirmed' && (
                    <button
                      onClick={() => updateBookingStatus(bkg.id, 'Cancelled')}
                      className="text-red-600 hover:text-red-700 font-semibold"
                    >
                      Cancel Appointment
                    </button>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* Reminders Tab */}
      {activeTab === 'reminders' && (
        <div className="bg-white rounded-3xl p-6 border border-gray-100 shadow-2xs space-y-4">
          <div>
            <h3 className="text-base font-black text-gray-900">Custom Plant Care Calendar</h3>
            <p className="text-xs text-gray-500">Automated moisture and fertilizing alerts tailored to the plants in your home</p>
          </div>

          <div className="space-y-2.5">
            {reminders.map(rem => {
              const Icon = rem.icon;
              return (
                <div
                  key={rem.id}
                  onClick={() => toggleReminder(rem.id)}
                  className={`p-4 rounded-2xl border cursor-pointer transition flex items-center justify-between ${
                    rem.done
                      ? 'bg-gray-50/70 border-gray-200 opacity-60'
                      : 'bg-emerald-50/50 border-emerald-100 hover:border-emerald-300'
                  }`}
                >
                  <div className="flex items-center space-x-3">
                    <div className={`w-6 h-6 rounded-lg flex items-center justify-center border ${
                      rem.done ? 'bg-emerald-600 text-white border-emerald-600' : 'bg-white border-gray-300'
                    }`}>
                      {rem.done && <Check className="w-4 h-4" />}
                    </div>
                    <div>
                      <h4 className={`text-xs font-bold ${rem.done ? 'line-through text-gray-500' : 'text-gray-900'}`}>
                        {rem.plant}
                      </h4>
                      <p className="text-xs text-gray-600 mt-0.5">{rem.task}</p>
                    </div>
                  </div>
                  <span className="text-[11px] font-bold text-emerald-800 bg-white px-2.5 py-1 rounded-lg border border-emerald-200">
                    {rem.due}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Wishlist Tab */}
      {activeTab === 'wishlist' && (
        <div className="space-y-4">
          {wishlistedProducts.length === 0 ? (
            <div className="bg-white rounded-3xl p-12 text-center border border-gray-100">
              <Heart className="w-12 h-12 text-gray-300 mx-auto mb-3" />
              <h3 className="font-bold text-gray-800 text-sm">Your wishlist is empty</h3>
              <p className="text-xs text-gray-500 mt-1">Tap the heart icon on any plant to bookmark it for later.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {wishlistedProducts.map(p => (
                <div
                  key={p.id}
                  className="bg-white rounded-2xl p-4 border border-gray-100 shadow-2xs flex items-center space-x-3"
                >
                  <img
                    src={p.image}
                    alt={p.name}
                    className="w-16 h-16 rounded-xl object-cover"
                  />
                  <div className="flex-1 min-w-0">
                    <h4 className="font-bold text-xs text-gray-900 truncate">{p.name}</h4>
                    <span className="font-black text-emerald-700 text-sm">${p.price.toFixed(2)}</span>
                    <div className="flex gap-2 mt-2">
                      <button
                        onClick={() => addToCart(p, 1)}
                        className="bg-emerald-700 text-white text-[10px] font-bold px-2.5 py-1 rounded-lg"
                      >
                        Add to Cart
                      </button>
                      <button
                        onClick={() => toggleWishlist(p.id)}
                        className="text-gray-400 hover:text-red-600 text-[10px]"
                      >
                        Remove
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
