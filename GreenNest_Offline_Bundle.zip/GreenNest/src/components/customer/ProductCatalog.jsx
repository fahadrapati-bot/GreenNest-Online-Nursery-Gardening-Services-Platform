import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import {
  INITIAL_CATEGORIES
} from '../../data/seedData';
import {
  Filter,
  Search,
  Star,
  SlidersHorizontal,
  X,
  ShoppingCart,
  Heart,
  Eye,
  Store,
  Check,
  Sprout,
  Sun,
  Droplets
} from 'lucide-react';

export const ProductCatalog = () => {
  const {
    products,
    selectedCategory,
    setSelectedCategory,
    searchQuery,
    setSearchQuery,
    setSelectedProduct,
    addToCart,
    wishlist,
    toggleWishlist,
    setIsCartOpen
  } = useApp();

  // Filter States
  const [filterType, setFilterType] = useState('all'); // 'all' | 'indoor' | 'outdoor'
  const [priceRange, setPriceRange] = useState('all'); // 'all' | 'under25' | '25to40' | 'above40'
  const [selectedLight, setSelectedLight] = useState('all');
  const [sortBy, setSortBy] = useState('featured'); // 'featured' | 'price-asc' | 'price-desc' | 'rating'
  const [showMobileFilters, setShowMobileFilters] = useState(false);

  // Filtered & Sorted Products
  const filteredProducts = useMemo(() => {
    return products.filter(item => {
      // Category check
      if (selectedCategory !== 'all') {
        if (item.category !== selectedCategory) return false;
      }

      // Indoor / Outdoor check
      if (filterType === 'indoor' && !item.isIndoor) return false;
      if (filterType === 'outdoor' && !item.isOutdoor) return false;

      // Price range check
      if (priceRange === 'under25' && item.price >= 25) return false;
      if (priceRange === '25to40' && (item.price < 25 || item.price > 40)) return false;
      if (priceRange === 'above40' && item.price <= 40) return false;

      // Light requirement check
      if (selectedLight !== 'all') {
        if (!item.light || !item.light.toLowerCase().includes(selectedLight.toLowerCase())) {
          return false;
        }
      }

      // Search Query
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        const matchesName = item.name.toLowerCase().includes(query);
        const matchesBotanical = item.botanicalName?.toLowerCase().includes(query);
        const matchesDesc = item.description?.toLowerCase().includes(query);
        const matchesTags = item.tags?.some(t => t.toLowerCase().includes(query));
        const matchesNursery = item.nurseryName?.toLowerCase().includes(query);
        if (!matchesName && !matchesBotanical && !matchesDesc && !matchesTags && !matchesNursery) {
          return false;
        }
      }

      return true;
    }).sort((a, b) => {
      if (sortBy === 'price-asc') return a.price - b.price;
      if (sortBy === 'price-desc') return b.price - a.price;
      if (sortBy === 'rating') return b.rating - a.rating;
      return 0; // featured default
    });
  }, [products, selectedCategory, filterType, priceRange, selectedLight, searchQuery, sortBy]);

  const clearFilters = () => {
    setSelectedCategory('all');
    setFilterType('all');
    setPriceRange('all');
    setSelectedLight('all');
    setSearchQuery('');
    setSortBy('featured');
  };

  const hasActiveFilters =
    selectedCategory !== 'all' ||
    filterType !== 'all' ||
    priceRange !== 'all' ||
    selectedLight !== 'all' ||
    searchQuery.trim() !== '';

  return (
    <div className="space-y-6">
      {/* Catalog Header & Category Pills */}
      <div className="bg-white rounded-3xl p-6 border border-emerald-100 shadow-xs space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-black text-gray-900">GreenNest Botanical Catalog</h1>
            <p className="text-xs text-gray-500 mt-1">
              Browse healthy potted plants, seeds, and gardening tools from certified nurseries
            </p>
          </div>

          <div className="flex items-center space-x-3">
            {/* Sort Dropdown */}
            <div className="flex items-center space-x-2 text-xs">
              <span className="text-gray-500 font-medium">Sort by:</span>
              <select
                value={sortBy}
                onChange={e => setSortBy(e.target.value)}
                className="bg-gray-50 border border-gray-200 rounded-xl px-3 py-2 text-xs font-semibold text-gray-800 focus:outline-hidden focus:border-emerald-500"
              >
                <option value="featured">Featured / Bestsellers</option>
                <option value="price-asc">Price: Low to High</option>
                <option value="price-desc">Price: High to Low</option>
                <option value="rating">Highest Rated</option>
              </select>
            </div>

            {/* Mobile Filter Button */}
            <button
              onClick={() => setShowMobileFilters(!showMobileFilters)}
              className="lg:hidden flex items-center space-x-1.5 bg-emerald-700 text-white px-3 py-2 rounded-xl text-xs font-bold"
            >
              <SlidersHorizontal className="w-3.5 h-3.5" />
              <span>Filters</span>
            </button>
          </div>
        </div>

        {/* Category Filter Chips */}
        <div className="flex items-center space-x-2 overflow-x-auto pb-2 scrollbar-none">
          {INITIAL_CATEGORIES.map(cat => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition flex items-center space-x-1.5 ${
                selectedCategory === cat.id
                  ? 'bg-emerald-700 text-white shadow-xs'
                  : 'bg-emerald-50/60 hover:bg-emerald-100/70 text-emerald-950 border border-emerald-100'
              }`}
            >
              <span>{cat.name}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Main Grid + Sidebar */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 items-start">
        {/* Filter Sidebar (Desktop & Mobile Drawer) */}
        <aside
          className={`bg-white rounded-3xl p-6 border border-emerald-100 shadow-xs space-y-6 ${
            showMobileFilters ? 'block' : 'hidden lg:block'
          }`}
        >
          <div className="flex items-center justify-between pb-3 border-b border-gray-100">
            <h3 className="font-bold text-sm text-gray-900 flex items-center space-x-2">
              <Filter className="w-4 h-4 text-emerald-600" />
              <span>Refine Catalog</span>
            </h3>
            {hasActiveFilters && (
              <button
                onClick={clearFilters}
                className="text-xs text-red-600 hover:text-red-700 font-semibold"
              >
                Reset All
              </button>
            )}
          </div>

          {/* Plant Type: Indoor vs Outdoor */}
          <div className="space-y-2 text-xs">
            <label className="font-bold text-gray-800 uppercase tracking-wider block">Environment</label>
            <div className="grid grid-cols-3 gap-1.5">
              {[
                { id: 'all', label: 'All' },
                { id: 'indoor', label: 'Indoor' },
                { id: 'outdoor', label: 'Outdoor' }
              ].map(opt => (
                <button
                  key={opt.id}
                  onClick={() => setFilterType(opt.id)}
                  className={`py-1.5 px-2 rounded-lg text-xs font-medium text-center transition ${
                    filterType === opt.id
                      ? 'bg-emerald-700 text-white font-bold'
                      : 'bg-gray-50 text-gray-700 hover:bg-gray-100 border border-gray-200'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          {/* Price Range */}
          <div className="space-y-2 text-xs">
            <label className="font-bold text-gray-800 uppercase tracking-wider block">Price Range</label>
            <div className="space-y-1.5">
              {[
                { id: 'all', label: 'All Prices' },
                { id: 'under25', label: 'Under $25' },
                { id: '25to40', label: '$25 to $40' },
                { id: 'above40', label: 'Above $40' }
              ].map(opt => (
                <label
                  key={opt.id}
                  className="flex items-center space-x-2 cursor-pointer text-gray-700 hover:text-emerald-800"
                >
                  <input
                    type="radio"
                    name="price"
                    value={opt.id}
                    checked={priceRange === opt.id}
                    onChange={() => setPriceRange(opt.id)}
                    className="text-emerald-600 focus:ring-emerald-500"
                  />
                  <span>{opt.label}</span>
                </label>
              ))}
            </div>
          </div>

          {/* Sunlight Requirement */}
          <div className="space-y-2 text-xs">
            <label className="font-bold text-gray-800 uppercase tracking-wider block flex items-center space-x-1">
              <Sun className="w-3.5 h-3.5 text-amber-500" />
              <span>Light Requirement</span>
            </label>
            <select
              value={selectedLight}
              onChange={e => setSelectedLight(e.target.value)}
              className="w-full p-2 bg-gray-50 border border-gray-200 rounded-xl focus:bg-white focus:border-emerald-500 text-xs"
            >
              <option value="all">Any Light Condition</option>
              <option value="Low">Low Light Tolerant</option>
              <option value="Indirect">Bright Indirect Light</option>
              <option value="Full">Full Sun / Direct</option>
            </select>
          </div>

          {/* Guaranteed Nursery Quality Banner */}
          <div className="bg-emerald-50/70 p-4 rounded-2xl border border-emerald-100 text-xs space-y-1">
            <span className="font-bold text-emerald-950 block">Direct Nursery Guarantee</span>
            <p className="text-gray-600 leading-relaxed text-[11px]">
              Every potted plant is hand-selected from Urbano Nursery beds on the morning of dispatch.
            </p>
          </div>
        </aside>

        {/* Product Cards Grid */}
        <main className="lg:col-span-3 space-y-4">
          <div className="flex items-center justify-between text-xs text-gray-500 px-1">
            <span>Showing <strong>{filteredProducts.length}</strong> items</span>
            {searchQuery && (
              <span>Filter: "<strong>{searchQuery}</strong>"</span>
            )}
          </div>

          {filteredProducts.length === 0 ? (
            <div className="bg-white rounded-3xl p-12 text-center border border-gray-100">
              <Sprout className="w-12 h-12 text-gray-300 mx-auto mb-3" />
              <h3 className="font-bold text-gray-800 text-base">No matching plants or supplies found</h3>
              <p className="text-xs text-gray-500 mt-1 max-w-sm mx-auto">
                Try widening your price range or clearing light/environmental filters to discover more items.
              </p>
              <button
                onClick={clearFilters}
                className="mt-4 bg-emerald-700 hover:bg-emerald-800 text-white font-bold px-4 py-2 rounded-xl text-xs transition"
              >
                Clear All Filters
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
              {filteredProducts.map(p => {
                const isFavorited = wishlist.includes(p.id);

                return (
                  <div
                    key={p.id}
                    className="bg-white rounded-3xl border border-gray-100 hover:border-emerald-200 overflow-hidden shadow-2xs hover:shadow-xl transition-all duration-300 flex flex-col justify-between group"
                  >
                    {/* Image Box */}
                    <div className="relative aspect-4/3 bg-emerald-50/30 overflow-hidden">
                      <img
                        src={p.image}
                        alt={p.name}
                        className="w-full h-full object-cover group-hover:scale-105 transition duration-500"
                      />

                      {/* Top Badges */}
                      <div className="absolute top-3 left-3 flex flex-col gap-1">
                        {p.isIndoor && (
                          <span className="bg-emerald-950/80 backdrop-blur-xs text-white text-[10px] font-bold px-2 py-0.5 rounded-full">
                            Indoor
                          </span>
                        )}
                        {p.isOutdoor && (
                          <span className="bg-amber-900/80 backdrop-blur-xs text-white text-[10px] font-bold px-2 py-0.5 rounded-full">
                            Outdoor
                          </span>
                        )}
                      </div>

                      {/* Wishlist Button */}
                      <button
                        onClick={() => toggleWishlist(p.id)}
                        className={`absolute top-3 right-3 p-2 rounded-full backdrop-blur-xs transition shadow-md ${
                          isFavorited
                            ? 'bg-red-50 text-red-600'
                            : 'bg-white/85 hover:bg-white text-gray-600 hover:text-red-500'
                        }`}
                        title={isFavorited ? 'Remove from wishlist' : 'Add to wishlist'}
                      >
                        <Heart className={`w-3.5 h-3.5 ${isFavorited ? 'fill-red-600' : ''}`} />
                      </button>

                      {/* Nursery Tag */}
                      <div className="absolute bottom-2 left-3 bg-white/90 backdrop-blur-xs px-2.5 py-0.5 rounded-full text-[10px] font-semibold text-emerald-900 flex items-center space-x-1 shadow-2xs">
                        <Store className="w-3 h-3 text-emerald-700" />
                        <span>{p.nurseryName}</span>
                      </div>
                    </div>

                    {/* Content Box */}
                    <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
                      <div>
                        {/* Rating & Stock Status */}
                        <div className="flex items-center justify-between text-xs mb-1">
                          <div className="flex items-center space-x-1 text-amber-500 font-bold text-xs">
                            <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                            <span>{p.rating}</span>
                            <span className="text-gray-400 font-normal">({p.reviewsCount})</span>
                          </div>
                          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                            p.stock > 0 ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                          }`}>
                            {p.stock > 0 ? 'In Stock' : 'Out of Stock'}
                          </span>
                        </div>

                        {/* Title */}
                        <h3
                          onClick={() => setSelectedProduct(p)}
                          className="font-black text-gray-900 text-sm hover:text-emerald-700 cursor-pointer line-clamp-1"
                        >
                          {p.name}
                        </h3>
                        {p.botanicalName && (
                          <p className="text-[11px] italic text-gray-400 truncate">{p.botanicalName}</p>
                        )}

                        {/* Light & Water indicators */}
                        {p.light && (
                          <div className="flex items-center space-x-3 mt-2 text-[11px] text-gray-500">
                            <span className="flex items-center space-x-1">
                              <Sun className="w-3 h-3 text-amber-500" />
                              <span className="truncate max-w-[100px]">{p.light}</span>
                            </span>
                            {p.water && (
                              <span className="flex items-center space-x-1">
                                <Droplets className="w-3 h-3 text-blue-500" />
                                <span className="truncate max-w-[90px]">{p.water}</span>
                              </span>
                            )}
                          </div>
                        )}
                      </div>

                      {/* Pricing & Add to Cart */}
                      <div className="pt-2 border-t border-gray-100 flex items-center justify-between">
                        <div>
                          <span className="text-base font-black text-emerald-800">
                            ${p.price.toFixed(2)}
                          </span>
                          {p.originalPrice && (
                            <span className="text-xs line-through text-gray-400 ml-1.5">
                              ${p.originalPrice.toFixed(2)}
                            </span>
                          )}
                        </div>

                        <div className="flex space-x-1.5">
                          <button
                            onClick={() => setSelectedProduct(p)}
                            className="p-2 rounded-xl border border-gray-200 text-gray-600 hover:bg-emerald-50 hover:text-emerald-800 transition"
                            title="View full care instructions"
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => addToCart(p, 1)}
                            disabled={p.stock <= 0}
                            className="bg-emerald-700 hover:bg-emerald-800 disabled:bg-gray-300 text-white px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center space-x-1 shadow-xs"
                          >
                            <ShoppingCart className="w-3.5 h-3.5" />
                            <span>Add</span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </main>
      </div>
    </div>
  );
};
