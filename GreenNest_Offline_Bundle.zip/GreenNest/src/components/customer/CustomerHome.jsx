import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  Sprout,
  Calendar,
  Sparkles,
  ShieldCheck,
  Truck,
  HeartHandshake,
  ArrowRight,
  Sun,
  Droplets,
  Star,
  CheckCircle2,
  Store
} from 'lucide-react';

export const CustomerHome = () => {
  const {
    setActiveCustomerTab,
    setIsQuizOpen,
    setSelectedCategory,
    products,
    setSelectedProduct,
    addToCart,
    setBookingService,
    services
  } = useApp();

  const featuredPlants = products.slice(0, 4);

  return (
    <div className="space-y-12">
      {/* Hero Banner */}
      <section className="relative rounded-3xl overflow-hidden bg-gradient-to-r from-emerald-950 via-emerald-900 to-teal-900 text-white shadow-2xl">
        <div className="absolute inset-0 opacity-20 bg-[radial-gradient(#a3e635_1px,transparent_1px)] [background-size:16px_16px]" />
        
        <div className="relative max-w-7xl mx-auto px-6 sm:px-10 py-16 lg:py-20 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          <div className="lg:col-span-7 space-y-6">
            <div className="inline-flex items-center space-x-2 bg-emerald-800/80 backdrop-blur-md px-3.5 py-1.5 rounded-full border border-emerald-600/50 text-emerald-200 text-xs font-semibold">
              <Sprout className="w-3.5 h-3.5 text-emerald-400" />
              <span>Direct From Urbano Nursery & Verified Horticulturalists</span>
            </div>

            <h1 className="text-3xl sm:text-5xl font-black tracking-tight leading-tight">
              Breathe Life Into Your Home with Handpicked Plants & Expert Gardeners.
            </h1>

            <p className="text-emerald-100/90 text-sm sm:text-base leading-relaxed max-w-xl">
              From lush indoor air-purifiers to scheduled doorstep lawn maintenance. Buy potted plants with a 7-day health guarantee and book verified gardening pros in clicks.
            </p>

            <div className="flex flex-wrap gap-3 pt-2">
              <button
                onClick={() => setActiveCustomerTab('shop')}
                className="bg-emerald-500 hover:bg-emerald-400 text-emerald-950 font-black px-6 py-3.5 rounded-2xl text-xs sm:text-sm transition flex items-center space-x-2 shadow-lg shadow-emerald-500/30"
              >
                <span>Shop Plants & Supplies</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={() => setActiveCustomerTab('services')}
                className="bg-emerald-900/80 hover:bg-emerald-850 text-white font-bold px-6 py-3.5 rounded-2xl text-xs sm:text-sm border border-emerald-600/60 transition flex items-center space-x-2"
              >
                <Calendar className="w-4 h-4 text-emerald-300" />
                <span>Book Home Gardener</span>
              </button>

              <button
                onClick={() => setIsQuizOpen(true)}
                className="bg-white/10 hover:bg-white/20 text-emerald-100 font-semibold px-4 py-3.5 rounded-2xl text-xs sm:text-sm backdrop-blur-xs transition flex items-center space-x-1.5"
              >
                <Sparkles className="w-4 h-4 text-amber-300" />
                <span>Plant Match Quiz</span>
              </button>
            </div>

            {/* Micro Stats */}
            <div className="pt-4 border-t border-emerald-800/60 grid grid-cols-3 gap-4 max-w-md text-xs">
              <div>
                <span className="block text-xl font-extrabold text-white">500+</span>
                <span className="text-emerald-300 text-[11px]">Nursery Species</span>
              </div>
              <div>
                <span className="block text-xl font-extrabold text-white">100%</span>
                <span className="text-emerald-300 text-[11px]">Verified Pros</span>
              </div>
              <div>
                <span className="block text-xl font-extrabold text-white">4.9 ★</span>
                <span className="text-emerald-300 text-[11px]">Customer Rating</span>
              </div>
            </div>
          </div>

          {/* Hero Visual Card */}
          <div className="lg:col-span-5 relative hidden lg:block">
            <div className="relative rounded-3xl overflow-hidden shadow-2xl border-4 border-emerald-800/60 group">
              <img
                src="https://images.unsplash.com/photo-1545241047-6083a3684587?auto=format&fit=crop&w=800&q=80"
                alt="GreenNest Nursery Plant"
                className="w-full h-96 object-cover group-hover:scale-105 transition duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-emerald-950/90 via-transparent to-transparent flex flex-col justify-end p-6">
                <span className="text-[10px] uppercase font-bold tracking-widest text-emerald-300 bg-emerald-900/80 px-2.5 py-0.5 rounded-full w-max mb-1">
                  Urbano Nursery Spotlight
                </span>
                <h3 className="text-lg font-black text-white">Fiddle Leaf Fig & Clay Planter</h3>
                <p className="text-xs text-emerald-200 mt-0.5">Architectural indoor statement foliage</p>
                <div className="mt-3 flex items-center justify-between">
                  <span className="text-lg font-black text-emerald-300">$49.99</span>
                  <button
                    onClick={() => {
                      const flf = products.find(p => p.id === 'prod-5');
                      if (flf) setSelectedProduct(flf);
                    }}
                    className="text-xs font-bold bg-white text-emerald-950 px-3 py-1.5 rounded-xl hover:bg-emerald-100 transition"
                  >
                    View Care Details
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Categories Grid */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl font-black text-gray-900">Explore Catalog Categories</h2>
            <p className="text-xs text-gray-500">Curated collections for balconies, desks, and expansive lawns</p>
          </div>
          <button
            onClick={() => setActiveCustomerTab('shop')}
            className="text-xs font-bold text-emerald-700 hover:text-emerald-900 flex items-center space-x-1"
          >
            <span>See All Products</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          {[
            { id: 'indoor', name: 'Indoor Plants', count: '120+ Varieties', img: 'https://images.unsplash.com/photo-1614594975525-e45190c55d0b?auto=format&fit=crop&w=400&q=80' },
            { id: 'outdoor', name: 'Outdoor Plants', count: '85+ Varieties', img: 'https://images.unsplash.com/photo-1516205651411-aef33a44f7c2?auto=format&fit=crop&w=400&q=80' },
            { id: 'flowering', name: 'Flowering Pots', count: '60+ Varieties', img: 'https://images.unsplash.com/photo-1593691509543-c55fb32e7355?auto=format&fit=crop&w=400&q=80' },
            { id: 'seeds', name: 'Seeds & Bulbs', count: '90+ Seed Kits', img: 'https://images.unsplash.com/photo-1592417817098-8f3d6eb22509?auto=format&fit=crop&w=400&q=80' },
            { id: 'pots', name: 'Clay & Planters', count: '45+ Designs', img: 'https://images.unsplash.com/photo-1485955900006-10f4d324d411?auto=format&fit=crop&w=400&q=80' },
            { id: 'tools', name: 'Tools & Compost', count: '30+ Essentials', img: 'https://images.unsplash.com/photo-1416879595882-3373a0480b5b?auto=format&fit=crop&w=400&q=80' },
          ].map(cat => (
            <div
              key={cat.id}
              onClick={() => {
                setSelectedCategory(cat.id);
                setActiveCustomerTab('shop');
              }}
              className="group cursor-pointer bg-white rounded-2xl border border-gray-100 hover:border-emerald-300 p-2.5 shadow-2xs hover:shadow-md transition text-center"
            >
              <div className="h-28 rounded-xl overflow-hidden mb-2 bg-emerald-50">
                <img
                  src={cat.img}
                  alt={cat.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition duration-500"
                />
              </div>
              <h3 className="text-xs font-bold text-gray-900 group-hover:text-emerald-800">{cat.name}</h3>
              <p className="text-[10px] text-gray-400">{cat.count}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Featured Plants Carousel/Grid */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl font-black text-gray-900">Bestsellers from Urbano Nursery</h2>
            <p className="text-xs text-gray-500">Acclimatized for apartments, low-maintenance & air purifying</p>
          </div>
          <button
            onClick={() => setActiveCustomerTab('shop')}
            className="text-xs font-bold text-emerald-700 hover:text-emerald-900 flex items-center space-x-1"
          >
            <span>View Catalog</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {featuredPlants.map(p => (
            <div
              key={p.id}
              className="bg-white rounded-2xl border border-gray-100 hover:border-emerald-200 overflow-hidden shadow-2xs hover:shadow-lg transition flex flex-col justify-between group"
            >
              <div className="relative">
                <img
                  src={p.image}
                  alt={p.name}
                  className="w-full h-48 object-cover group-hover:scale-105 transition duration-500"
                />
                <div className="absolute top-3 left-3">
                  <span className="bg-emerald-900/80 backdrop-blur-xs text-white text-[10px] font-bold px-2 py-0.5 rounded-full">
                    {p.type}
                  </span>
                </div>
              </div>

              <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
                <div>
                  <div className="flex items-center justify-between text-xs mb-1">
                    <span className="text-[11px] font-medium text-emerald-700">{p.nurseryName}</span>
                    <div className="flex items-center space-x-1 text-amber-500 font-bold text-[11px]">
                      <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                      <span>{p.rating}</span>
                    </div>
                  </div>
                  <h3
                    onClick={() => setSelectedProduct(p)}
                    className="font-bold text-gray-900 text-sm hover:text-emerald-700 cursor-pointer line-clamp-1"
                  >
                    {p.name}
                  </h3>
                  <p className="text-xs text-gray-500 line-clamp-2 mt-1">{p.description}</p>
                </div>

                <div className="pt-2 border-t border-gray-100 flex items-center justify-between">
                  <div>
                    <span className="text-base font-black text-emerald-800">${p.price.toFixed(2)}</span>
                    {p.originalPrice && (
                      <span className="text-xs line-through text-gray-400 ml-1.5">
                        ${p.originalPrice.toFixed(2)}
                      </span>
                    )}
                  </div>
                  <div className="flex space-x-1">
                    <button
                      onClick={() => setSelectedProduct(p)}
                      className="px-2.5 py-1.5 rounded-lg border border-gray-200 text-gray-600 hover:bg-gray-50 text-xs font-bold"
                    >
                      Details
                    </button>
                    <button
                      onClick={() => addToCart(p, 1)}
                      className="bg-emerald-700 hover:bg-emerald-800 text-white px-3 py-1.5 rounded-lg text-xs font-bold transition shadow-xs"
                    >
                      Add
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Book Gardener Spotlight Section */}
      <section className="bg-gradient-to-br from-emerald-50 via-teal-50/50 to-green-50 border border-emerald-100 rounded-3xl p-6 sm:p-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          <div className="lg:col-span-7 space-y-4">
            <span className="text-xs font-bold uppercase tracking-widest text-emerald-800 bg-emerald-200/60 px-3 py-1 rounded-full">
              Hassle-Free Home Gardening Services
            </span>
            <h2 className="text-2xl sm:text-3xl font-black text-gray-900">
              Need Help With Pruning, Repotting or Lawn Mowing?
            </h2>
            <p className="text-xs sm:text-sm text-gray-600 leading-relaxed max-w-xl">
              No more searching for unverified local gardeners or negotiating manual phone rates. Book certified, background-checked horticultural experts with transparent pricing and standard equipment.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
              <div className="flex items-center space-x-2.5 bg-white p-3 rounded-xl border border-emerald-100 shadow-2xs">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span className="text-xs text-gray-800 font-semibold">Trained in organic pest eradication</span>
              </div>
              <div className="flex items-center space-x-2.5 bg-white p-3 rounded-xl border border-emerald-100 shadow-2xs">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span className="text-xs text-gray-800 font-semibold">Carries bypass shears & potting tools</span>
              </div>
              <div className="flex items-center space-x-2.5 bg-white p-3 rounded-xl border border-emerald-100 shadow-2xs">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span className="text-xs text-gray-800 font-semibold">Select preferred 2-hour visit window</span>
              </div>
              <div className="flex items-center space-x-2.5 bg-white p-3 rounded-xl border border-emerald-100 shadow-2xs">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span className="text-xs text-gray-800 font-semibold">Satisfaction guaranteed or re-service</span>
              </div>
            </div>

            <div className="pt-3">
              <button
                onClick={() => setActiveCustomerTab('services')}
                className="bg-emerald-700 hover:bg-emerald-800 text-white font-bold px-6 py-3 rounded-xl text-xs sm:text-sm shadow-md shadow-emerald-700/20 transition flex items-center space-x-2"
              >
                <Calendar className="w-4 h-4" />
                <span>View All Gardening Services & Book</span>
              </button>
            </div>
          </div>

          <div className="lg:col-span-5 grid grid-cols-1 gap-3">
            {services.slice(0, 2).map(serv => (
              <div
                key={serv.id}
                className="bg-white p-4 rounded-2xl border border-gray-100 shadow-xs hover:shadow-md transition flex flex-col justify-between space-y-2"
              >
                <div>
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-emerald-800">{serv.duration}</span>
                    <span className="text-sm font-black text-gray-900">${serv.price.toFixed(2)}</span>
                  </div>
                  <h4 className="font-bold text-gray-900 text-sm mt-1">{serv.name}</h4>
                  <p className="text-xs text-gray-500 mt-0.5">{serv.tagline}</p>
                </div>
                <button
                  onClick={() => setBookingService(serv)}
                  className="w-full bg-emerald-50 hover:bg-emerald-100 text-emerald-800 font-bold py-2 rounded-xl text-xs transition flex items-center justify-center space-x-1"
                >
                  <span>Book This Service</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};
