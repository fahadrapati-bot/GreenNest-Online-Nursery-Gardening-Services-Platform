import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  X,
  Calendar,
  Clock,
  MapPin,
  CheckCircle,
  Star,
  ShieldCheck,
  ArrowRight,
  UserCheck,
  CheckCircle2,
  CalendarCheck
} from 'lucide-react';

export const ServiceBookingModal = () => {
  const {
    bookingService,
    setBookingService,
    gardeners,
    createBooking,
    setActiveCustomerTab
  } = useApp();

  const [step, setStep] = useState(1); // 1: Details & Gardener, 2: Confirmation
  const [selectedGardenerId, setSelectedGardenerId] = useState('gardener-1');
  const [bookingDate, setBookingDate] = useState('2026-09-20');
  const [timeSlot, setTimeSlot] = useState('11:30 AM');
  const [gardenType, setGardenType] = useState('Balcony Garden (10-25 Pots)');
  const [notes, setNotes] = useState('Need general pruning, soil loosening, and inspection for pests on flowering plants.');
  
  const [contact, setContact] = useState({
    name: 'Aarav Sharma',
    email: 'aarav.sharma@example.com',
    phone: '+91 98765 43210',
    address: 'Flat 402, Green Meadows Residency, 12th Main Road, Indiranagar, Bengaluru'
  });

  const [confirmedBooking, setConfirmedBooking] = useState(null);

  if (!bookingService) return null;

  const chosenGardener = gardeners.find(g => g.id === selectedGardenerId) || gardeners[0];

  const handleConfirm = (e) => {
    e.preventDefault();
    const newBkg = createBooking({
      serviceId: bookingService.id,
      serviceName: bookingService.name,
      gardenerId: chosenGardener.id,
      gardenerName: chosenGardener.name,
      gardenerPhone: '+91 98450 11223',
      name: contact.name,
      email: contact.email,
      phone: contact.phone,
      address: contact.address,
      gardenType,
      date: bookingDate,
      timeSlot,
      price: bookingService.price,
      notes
    });
    setConfirmedBooking(newBkg);
  };

  const handleClose = () => {
    setConfirmedBooking(null);
    setBookingService(null);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-2xl w-full shadow-2xl overflow-hidden border border-gray-100 my-6">
        {/* Booking Confirmed State */}
        {confirmedBooking ? (
          <div className="p-8 text-center space-y-5">
            <div className="w-16 h-16 bg-emerald-100 text-emerald-700 rounded-full flex items-center justify-center mx-auto ring-8 ring-emerald-50 animate-bounce">
              <CalendarCheck className="w-8 h-8" />
            </div>

            <div>
              <span className="text-xs font-bold uppercase tracking-widest text-emerald-700 bg-emerald-100/60 px-3 py-1 rounded-full">
                Service Booked
              </span>
              <h2 className="text-2xl font-black text-gray-900 mt-2">
                Gardener Booking Confirmed!
              </h2>
              <p className="text-xs text-gray-600 mt-1 max-w-md mx-auto">
                {confirmedBooking.gardenerName} has received your service appointment and will arrive equipped with organic fertilizers and professional tools.
              </p>
            </div>

            <div className="bg-emerald-50/70 border border-emerald-100 rounded-2xl p-4 text-left space-y-2 text-xs">
              <div className="flex justify-between border-b border-emerald-200/50 pb-2">
                <span className="text-gray-500">Booking ID:</span>
                <span className="font-bold text-gray-900">{confirmedBooking.id}</span>
              </div>
              <div className="flex justify-between border-b border-emerald-200/50 pb-2">
                <span className="text-gray-500">Service:</span>
                <span className="font-bold text-gray-900">{confirmedBooking.serviceName}</span>
              </div>
              <div className="flex justify-between border-b border-emerald-200/50 pb-2">
                <span className="text-gray-500">Scheduled Date & Time:</span>
                <span className="font-bold text-emerald-800">{confirmedBooking.date} at {confirmedBooking.timeSlot}</span>
              </div>
              <div className="flex justify-between border-b border-emerald-200/50 pb-2">
                <span className="text-gray-500">Assigned Pro:</span>
                <span className="font-bold text-gray-900">{confirmedBooking.gardenerName} ({confirmedBooking.gardenerPhone})</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">Total Service Fee:</span>
                <span className="font-black text-emerald-700 text-sm">${confirmedBooking.price.toFixed(2)}</span>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-3 pt-2">
              <button
                onClick={() => {
                  handleClose();
                  setActiveCustomerTab('bookings');
                }}
                className="flex-1 bg-emerald-700 hover:bg-emerald-800 text-white font-bold py-3 px-4 rounded-xl text-xs transition flex items-center justify-center space-x-1.5 shadow-md shadow-emerald-700/20"
              >
                <span>View in My Bookings</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={handleClose}
                className="bg-gray-100 hover:bg-gray-200 text-gray-700 font-bold py-3 px-4 rounded-xl text-xs transition"
              >
                Done
              </button>
            </div>
          </div>
        ) : (
          /* Booking Form */
          <div>
            {/* Header */}
            <div className="p-5 border-b border-gray-100 flex items-center justify-between bg-emerald-900 text-white">
              <div className="flex items-center space-x-3">
                <div className="p-2.5 rounded-xl bg-emerald-800 text-emerald-300">
                  <Calendar className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-300">
                    Book Home Gardener Service
                  </span>
                  <h3 className="font-bold text-base text-white">{bookingService.name}</h3>
                </div>
              </div>
              <button
                onClick={handleClose}
                className="p-1 rounded-lg text-emerald-200 hover:text-white hover:bg-emerald-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleConfirm} className="p-6 space-y-5 text-xs">
              {/* Step 1: Pick Pro Gardener */}
              <div>
                <label className="block text-xs font-bold text-gray-900 uppercase tracking-wider mb-2">
                  Select Verified Gardener Pro
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                  {gardeners.map(g => (
                    <div
                      key={g.id}
                      onClick={() => setSelectedGardenerId(g.id)}
                      className={`p-3 rounded-2xl border cursor-pointer transition flex flex-col justify-between ${
                        selectedGardenerId === g.id
                          ? 'border-emerald-600 bg-emerald-50/70 ring-1 ring-emerald-600'
                          : 'border-gray-200 hover:border-gray-300 bg-white'
                      }`}
                    >
                      <div className="flex items-center space-x-2">
                        <img
                          src={g.image}
                          alt={g.name}
                          className="w-10 h-10 rounded-full object-cover border border-gray-200"
                        />
                        <div>
                          <div className="flex items-center space-x-1">
                            <span className="font-bold text-gray-900 text-xs">{g.name}</span>
                            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                          </div>
                          <div className="flex items-center space-x-1 text-amber-500 font-bold text-[10px]">
                            <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                            <span>{g.rating}</span>
                            <span className="text-gray-400">({g.completedJobs} jobs)</span>
                          </div>
                        </div>
                      </div>
                      <div className="mt-2 pt-2 border-t border-gray-100 flex items-center justify-between text-[11px]">
                        <span className="text-gray-500">{g.experience}</span>
                        <span className="font-bold text-emerald-800">${g.hourlyRate}/hr</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Step 2: Date & Slot */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold text-gray-900 uppercase tracking-wider mb-1.5">
                    Preferred Date
                  </label>
                  <input
                    type="date"
                    required
                    value={bookingDate}
                    min="2026-09-19"
                    onChange={e => setBookingDate(e.target.value)}
                    className="w-full p-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:bg-white focus:border-emerald-500 focus:outline-hidden"
                  />
                </div>

                <div>
                  <label className="block font-bold text-gray-900 uppercase tracking-wider mb-1.5">
                    Time Window
                  </label>
                  <select
                    value={timeSlot}
                    onChange={e => setTimeSlot(e.target.value)}
                    className="w-full p-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:bg-white focus:border-emerald-500 focus:outline-hidden"
                  >
                    <option>09:00 AM (Morning Slot)</option>
                    <option>11:30 AM (Pre-Noon Slot)</option>
                    <option>02:00 PM (Afternoon Slot)</option>
                    <option>04:30 PM (Evening Slot)</option>
                  </select>
                </div>
              </div>

              {/* Step 3: Garden Type & Special Instructions */}
              <div className="space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block font-medium text-gray-700 mb-1">Garden / Space Type</label>
                    <select
                      value={gardenType}
                      onChange={e => setGardenType(e.target.value)}
                      className="w-full p-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:bg-white focus:border-emerald-500 focus:outline-hidden"
                    >
                      <option>Balcony Garden (10-25 Pots)</option>
                      <option>Terrace Garden (25-60 Pots)</option>
                      <option>Indoor Plant Collection</option>
                      <option>Lawn & Ground Garden Yard</option>
                    </select>
                  </div>

                  <div>
                    <label className="block font-medium text-gray-700 mb-1">Contact Phone</label>
                    <input
                      type="tel"
                      required
                      value={contact.phone}
                      onChange={e => setContact({ ...contact, phone: e.target.value })}
                      className="w-full p-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:bg-white focus:border-emerald-500 focus:outline-hidden"
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-medium text-gray-700 mb-1">Service Address</label>
                  <input
                    type="text"
                    required
                    value={contact.address}
                    onChange={e => setContact({ ...contact, address: e.target.value })}
                    className="w-full p-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:bg-white focus:border-emerald-500 focus:outline-hidden"
                  />
                </div>

                <div>
                  <label className="block font-medium text-gray-700 mb-1">Specific Plant Concerns / Requests</label>
                  <textarea
                    rows={2}
                    value={notes}
                    onChange={e => setNotes(e.target.value)}
                    placeholder="E.g., Need neem oil treatment for white insects on hibiscus, prune monstera..."
                    className="w-full p-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:bg-white focus:border-emerald-500 focus:outline-hidden"
                  />
                </div>
              </div>

              {/* Service Fee Summary */}
              <div className="bg-emerald-50/70 border border-emerald-100 rounded-2xl p-4 flex items-center justify-between">
                <div>
                  <span className="font-bold text-emerald-950 block text-sm">Package Total</span>
                  <span className="text-gray-500 text-[11px]">Includes gardener labor, tool usage & organic compost application</span>
                </div>
                <div className="text-right">
                  <span className="text-xl font-black text-emerald-800">${bookingService.price.toFixed(2)}</span>
                  <span className="block text-[10px] text-gray-500">Pay Online or Post-Service</span>
                </div>
              </div>

              {/* Confirm Button */}
              <button
                type="submit"
                className="w-full bg-emerald-700 hover:bg-emerald-800 text-white font-bold py-3.5 px-4 rounded-xl shadow-lg shadow-emerald-700/25 flex items-center justify-center space-x-2 text-sm transition"
              >
                <span>Confirm Service Appointment (${bookingService.price.toFixed(2)})</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          </div>
        )}
      </div>
    </div>
  );
};
