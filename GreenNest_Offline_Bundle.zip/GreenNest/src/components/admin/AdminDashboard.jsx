import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  ShieldCheck,
  Users,
  Store,
  Calendar,
  AlertTriangle,
  CheckCircle,
  XCircle,
  TrendingUp,
  Package,
  Layers,
  FileText,
  Search,
  Check
} from 'lucide-react';

export const AdminDashboard = () => {
  const {
    products,
    orders,
    bookings,
    applications,
    reviewApplication,
    disputes,
    resolveDispute,
    deleteProduct
  } = useApp();

  const [activeTab, setActiveTab] = useState('approvals'); // 'approvals' | 'orders' | 'disputes' | 'catalog'
  const [resolutionNote, setResolutionNote] = useState('');
  const [selectedDisputeId, setSelectedDisputeId] = useState(null);

  const pendingApps = applications.filter(a => a.status === 'Pending');
  const openDisputes = disputes.filter(d => d.status === 'Open');

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-purple-950 via-slate-900 to-emerald-950 text-white rounded-3xl p-6 sm:p-8 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center space-x-3">
            <div className="p-3 bg-purple-800/80 rounded-2xl border border-purple-600/50">
              <ShieldCheck className="w-8 h-8 text-purple-300" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h1 className="text-2xl font-black">Unified Mentor Platform Operations</h1>
                <span className="bg-purple-500 text-white text-[10px] font-bold px-2 py-0.5 rounded-full">
                  Super Admin
                </span>
              </div>
              <p className="text-xs text-purple-200 mt-0.5">
                Centralized Governance, KYC Approvals & Marketplace Monitoring
              </p>
            </div>
          </div>

          <div className="text-right">
            <span className="text-xs text-purple-300 block">System Health</span>
            <span className="text-xs font-bold text-emerald-400 flex items-center justify-end space-x-1 mt-0.5">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
              <span>All Services Operational</span>
            </span>
          </div>
        </div>

        {/* Platform KPIs */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-6 pt-6 border-t border-purple-800/60 text-xs">
          <div className="bg-purple-900/30 p-3.5 rounded-2xl border border-purple-800/40">
            <span className="text-purple-300">Total Platform Orders</span>
            <span className="text-2xl font-black text-white block mt-1">{orders.length}</span>
            <span className="text-[10px] text-emerald-400 mt-1 block">↑ 18.2% this week</span>
          </div>

          <div className="bg-purple-900/30 p-3.5 rounded-2xl border border-purple-800/40">
            <span className="text-purple-300">Gardener Visits Booked</span>
            <span className="text-2xl font-black text-white block mt-1">{bookings.length}</span>
            <span className="text-[10px] text-emerald-400 mt-1 block">98.4% Fulfillment</span>
          </div>

          <div className="bg-purple-900/30 p-3.5 rounded-2xl border border-purple-800/40">
            <span className="text-purple-300">Pending Approvals</span>
            <span className="text-2xl font-black text-amber-300 block mt-1">{pendingApps.length}</span>
            <span className="text-[10px] text-amber-200 mt-1 block">Requires KYC verification</span>
          </div>

          <div className="bg-purple-900/30 p-3.5 rounded-2xl border border-purple-800/40">
            <span className="text-purple-300">Open Disputes</span>
            <span className="text-2xl font-black text-rose-300 block mt-1">{openDisputes.length}</span>
            <span className="text-[10px] text-rose-200 mt-1 block">Customer ticket SLA &lt; 24h</span>
          </div>
        </div>
      </div>

      {/* Admin Tabs */}
      <div className="flex bg-white p-1.5 rounded-2xl border border-gray-200 text-xs font-bold w-max overflow-x-auto">
        <button
          onClick={() => setActiveTab('approvals')}
          className={`px-4 py-2 rounded-xl transition flex items-center space-x-1.5 ${
            activeTab === 'approvals' ? 'bg-purple-900 text-white shadow-xs' : 'text-gray-600 hover:text-gray-900'
          }`}
        >
          <Store className="w-3.5 h-3.5" />
          <span>Vendor & Pro KYC Queue ({pendingApps.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('orders')}
          className={`px-4 py-2 rounded-xl transition flex items-center space-x-1.5 ${
            activeTab === 'orders' ? 'bg-purple-900 text-white shadow-xs' : 'text-gray-600 hover:text-gray-900'
          }`}
        >
          <Package className="w-3.5 h-3.5" />
          <span>Master Orders & Bookings</span>
        </button>

        <button
          onClick={() => setActiveTab('catalog')}
          className={`px-4 py-2 rounded-xl transition flex items-center space-x-1.5 ${
            activeTab === 'catalog' ? 'bg-purple-900 text-white shadow-xs' : 'text-gray-600 hover:text-gray-900'
          }`}
        >
          <Layers className="w-3.5 h-3.5" />
          <span>Catalog Oversight ({products.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('disputes')}
          className={`px-4 py-2 rounded-xl transition flex items-center space-x-1.5 ${
            activeTab === 'disputes' ? 'bg-purple-900 text-white shadow-xs' : 'text-gray-600 hover:text-gray-900'
          }`}
        >
          <AlertTriangle className="w-3.5 h-3.5" />
          <span>Disputes & Tickets ({openDisputes.length})</span>
        </button>
      </div>

      {/* Tab 1: KYC Approvals */}
      {activeTab === 'approvals' && (
        <div className="bg-white rounded-3xl p-6 border border-gray-100 shadow-xs space-y-4">
          <div>
            <h3 className="font-bold text-gray-900 text-base">New Nursery & Gardener Verification Requests</h3>
            <p className="text-xs text-gray-500">
              Review horticultural licenses, location, and credentials before granting marketplace listing privileges
            </p>
          </div>

          <div className="space-y-3">
            {applications.map(app => (
              <div
                key={app.id}
                className="p-4 rounded-2xl border border-gray-200 bg-gray-50/50 flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-xs"
              >
                <div className="space-y-1">
                  <div className="flex items-center space-x-2">
                    <span className="font-black text-gray-900 text-sm">{app.name}</span>
                    <span className="bg-purple-100 text-purple-800 font-bold px-2 py-0.5 rounded-full text-[10px]">
                      {app.type}
                    </span>
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                      app.status === 'Approved'
                        ? 'bg-green-100 text-green-800'
                        : app.status === 'Rejected'
                        ? 'bg-red-100 text-red-800'
                        : 'bg-amber-100 text-amber-800'
                    }`}>
                      {app.status}
                    </span>
                  </div>
                  <p className="text-gray-600">Contact: {app.contactPerson} ({app.phone}) • {app.location}</p>
                  <p className="text-[11px] text-gray-500 italic">License / ID: {app.licenseNumber} • {app.details}</p>
                </div>

                {app.status === 'Pending' ? (
                  <div className="flex space-x-2 shrink-0">
                    <button
                      onClick={() => reviewApplication(app.id, 'Approved')}
                      className="bg-emerald-700 hover:bg-emerald-800 text-white font-bold px-3.5 py-2 rounded-xl transition flex items-center space-x-1"
                    >
                      <CheckCircle className="w-3.5 h-3.5" />
                      <span>Approve & Verify</span>
                    </button>
                    <button
                      onClick={() => reviewApplication(app.id, 'Rejected')}
                      className="bg-rose-100 hover:bg-rose-200 text-rose-800 font-bold px-3 py-2 rounded-xl transition"
                    >
                      Reject
                    </button>
                  </div>
                ) : (
                  <span className="text-gray-400 font-semibold italic">Reviewed</span>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 2: Orders & Bookings Master Monitor */}
      {activeTab === 'orders' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Orders */}
          <div className="bg-white rounded-3xl p-6 border border-gray-100 shadow-xs space-y-4">
            <h3 className="font-bold text-gray-900 text-base">Customer Orders Audit</h3>
            <div className="space-y-2 text-xs">
              {orders.map(o => (
                <div key={o.id} className="p-3 bg-gray-50 rounded-xl border border-gray-200 flex justify-between items-center">
                  <div>
                    <span className="font-bold text-gray-900">{o.id}</span>
                    <p className="text-gray-500 text-[11px]">{o.customerName} • {o.items.length} items</p>
                  </div>
                  <div className="text-right">
                    <span className="font-black text-emerald-800">${o.total.toFixed(2)}</span>
                    <span className="block text-[10px] text-gray-400">{o.status}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Bookings */}
          <div className="bg-white rounded-3xl p-6 border border-gray-100 shadow-xs space-y-4">
            <h3 className="font-bold text-gray-900 text-base">Gardener Appointments Audit</h3>
            <div className="space-y-2 text-xs">
              {bookings.map(b => (
                <div key={b.id} className="p-3 bg-gray-50 rounded-xl border border-gray-200 flex justify-between items-center">
                  <div>
                    <span className="font-bold text-gray-900">{b.id}</span>
                    <p className="text-gray-500 text-[11px]">{b.serviceName} • {b.gardenerName}</p>
                  </div>
                  <div className="text-right">
                    <span className="font-black text-emerald-800">${b.price.toFixed(2)}</span>
                    <span className="block text-[10px] text-gray-400">{b.status}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Tab 3: Catalog Oversight */}
      {activeTab === 'catalog' && (
        <div className="bg-white rounded-3xl p-6 border border-gray-100 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-bold text-gray-900 text-base">Platform Catalog Moderation</h3>
              <p className="text-xs text-gray-500">Monitor plant listings across Urbano Nursery and partner vendors</p>
            </div>
            <span className="text-xs text-gray-500">{products.length} listed products</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 text-xs">
            {products.map(p => (
              <div key={p.id} className="p-3 rounded-2xl border border-gray-200 flex items-center justify-between bg-gray-50/50">
                <div className="flex items-center space-x-2.5">
                  <img src={p.image} alt={p.name} className="w-10 h-10 rounded-lg object-cover" />
                  <div>
                    <h4 className="font-bold text-gray-900 truncate max-w-[150px]">{p.name}</h4>
                    <span className="text-[10px] text-emerald-700 font-medium">{p.nurseryName}</span>
                  </div>
                </div>
                <div className="text-right">
                  <span className="font-bold text-gray-900">${p.price.toFixed(2)}</span>
                  <button
                    onClick={() => deleteProduct(p.id)}
                    className="block text-[10px] text-red-600 hover:underline mt-1"
                  >
                    De-list
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 4: Disputes */}
      {activeTab === 'disputes' && (
        <div className="bg-white rounded-3xl p-6 border border-gray-100 shadow-xs space-y-4">
          <div>
            <h3 className="font-bold text-gray-900 text-base">Customer Support & Dispute Resolution</h3>
            <p className="text-xs text-gray-500">Mediate issues between customers, nurseries, and gardeners</p>
          </div>

          <div className="space-y-3 text-xs">
            {disputes.map(disp => (
              <div key={disp.id} className="p-4 rounded-2xl border border-gray-200 bg-gray-50/50 space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <span className="font-black text-gray-900">{disp.id}</span>
                    <span className="text-purple-800 font-bold bg-purple-100 px-2 py-0.5 rounded-full text-[10px]">
                      {disp.type}
                    </span>
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                      disp.status === 'Resolved' ? 'bg-green-100 text-green-800' : 'bg-rose-100 text-rose-800'
                    }`}>
                      {disp.status}
                    </span>
                  </div>
                  <span className="text-gray-400 text-[11px]">{disp.date}</span>
                </div>

                <p className="text-gray-700">{disp.description}</p>
                <div className="text-gray-500 text-[11px]">
                  Customer: <strong>{disp.customerName}</strong> • Counterparty: <strong>{disp.vendorOrGardener}</strong>
                </div>

                {disp.status === 'Open' ? (
                  <div className="pt-2 flex items-center space-x-2">
                    <button
                      onClick={() => resolveDispute(disp.id, 'Resolved with replacement guarantee')}
                      className="bg-emerald-700 hover:bg-emerald-800 text-white font-bold px-3 py-1.5 rounded-lg text-xs transition"
                    >
                      Resolve & Issue Replacement
                    </button>
                    <button
                      onClick={() => resolveDispute(disp.id, 'Dismissed after review')}
                      className="bg-gray-200 hover:bg-gray-300 text-gray-700 font-bold px-3 py-1.5 rounded-lg text-xs transition"
                    >
                      Dismiss
                    </button>
                  </div>
                ) : (
                  <p className="text-emerald-700 font-semibold text-[11px] pt-1">
                    ✓ Resolution Note: {disp.resolutionNote}
                  </p>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
