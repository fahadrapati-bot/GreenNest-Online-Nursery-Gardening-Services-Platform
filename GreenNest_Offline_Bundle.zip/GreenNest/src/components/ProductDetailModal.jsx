import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  X,
  Star,
  Sun,
  Droplets,
  Thermometer,
  Sparkles,
  Heart,
  Plus,
  Minus,
  ShoppingCart,
  ShieldCheck,
  Store,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';

export const ProductDetailModal = () => {
  const {
    selectedProduct,
    setSelectedProduct,
    addToCart,
    wishlist,
    toggleWishlist,
    setIsCartOpen
  } = useApp();

  const [quantity, setQuantity] = useState(1);
  const [activeTab, setActiveTab] = useState('care'); // 'care' | 'overview' | 'reviews'

  if (!selectedProduct) return null;

  const isFavorited = wishlist.includes(selectedProduct.id);

  const handleAddToCart = () => {
    addToCart(selectedProduct, quantity);
    setIsCartOpen(true);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-3xl w-full shadow-2xl overflow-hidden border border-gray-100 my-6 relative">
        {/* Close button */}
        <button
          onClick={() => setSelectedProduct(null)}
          className="absolute right-4 top-4 z-10 w-9 h-9 bg-white/90 hover:bg-white text-gray-700 hover:text-gray-900 rounded-full shadow-md flex items-center justify-center transition"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="grid grid-cols-1 md:grid-cols-2">
          {/* Product Image Gallery */}
          <div className="relative bg-emerald-50/50 p-6 flex flex-col items-center justify-center border-b md:border-b-0 md:border-r border-gray-100">
            <img
              src={selectedProduct.image}
              alt={selectedProduct.name}
              className="w-full h-80 object-cover rounded-2xl shadow-lg shadow-emerald-950/10"
            />

            {/* Floating Tags */}
            <div className="absolute top-8 left-8 flex flex-col gap-1.5">
              {selectedProduct.tags && selectedProduct.tags.map((tag, idx) => (
                <span
                  key={idx}
                  className="bg-emerald-900/90 backdrop-blur-xs text-white text-[10px] font-bold px-2.5 py-1 rounded-full shadow-xs"
                >
                  {tag}
                </span>
              ))}
            </div>

            {/* Nursery Origin */}
            <div className="mt-4 flex items-center space-x-2 text-xs text-emerald-900 bg-white/80 backdrop-blur-xs px-3 py-1.5 rounded-full border border-emerald-200">
              <Store className="w-3.5 h-3.5 text-emerald-700" />
              <span>Grown & nurtured by <strong>{selectedProduct.nurseryName}</strong></span>
            </div>
          </div>

          {/* Product Info Column */}
          <div className="p-6 sm:p-8 flex flex-col justify-between space-y-5">
            <div>
              {/* Category & Botanical */}
              <div className="flex items-center justify-between text-xs mb-1">
                <span className="text-emerald-700 font-bold uppercase tracking-wider">
                  {selectedProduct.type || selectedProduct.category}
                </span>
                <div className="flex items-center space-x-1 text-amber-500 font-bold">
                  <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
                  <span>{selectedProduct.rating}</span>
                  <span className="text-gray-400 font-normal">({selectedProduct.reviewsCount})</span>
                </div>
              </div>

              <h2 className="text-xl sm:text-2xl font-black text-gray-900 leading-tight">
                {selectedProduct.name}
              </h2>
              {selectedProduct.botanicalName && (
                <p className="text-xs italic text-gray-500 mt-0.5">{selectedProduct.botanicalName}</p>
              )}

              {/* Price & Stock */}
              <div className="mt-3 flex items-baseline space-x-3">
                <span className="text-2xl font-black text-emerald-700">
                  ${selectedProduct.price.toFixed(2)}
                </span>
                {selectedProduct.originalPrice && (
                  <span className="text-sm line-through text-gray-400">
                    ${selectedProduct.originalPrice.toFixed(2)}
                  </span>
                )}
                <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                  Save ${(selectedProduct.originalPrice - selectedProduct.price).toFixed(2)}
                </span>
              </div>

              <div className="mt-2 flex items-center space-x-2 text-xs">
                <span className={`w-2 h-2 rounded-full ${selectedProduct.stock > 5 ? 'bg-emerald-500' : 'bg-amber-500'}`} />
                <span className="font-semibold text-gray-700">
                  {selectedProduct.stock > 0 ? `${selectedProduct.stock} units available` : 'Temporarily Out of Stock'}
                </span>
              </div>

              {/* Quick Spec Pills */}
              <div className="grid grid-cols-3 gap-2 mt-4 text-center">
                <div className="bg-emerald-50/60 p-2 rounded-xl border border-emerald-100">
                  <Sun className="w-4 h-4 text-amber-600 mx-auto mb-1" />
                  <span className="text-[10px] text-gray-500 block">Light</span>
                  <span className="text-[11px] font-bold text-gray-800 truncate block">
                    {selectedProduct.light || 'Medium'}
                  </span>
                </div>

                <div className="bg-emerald-50/60 p-2 rounded-xl border border-emerald-100">
                  <Droplets className="w-4 h-4 text-blue-600 mx-auto mb-1" />
                  <span className="text-[10px] text-gray-500 block">Water</span>
                  <span className="text-[11px] font-bold text-gray-800 truncate block">
                    {selectedProduct.water || 'Regular'}
                  </span>
                </div>

                <div className="bg-emerald-50/60 p-2 rounded-xl border border-emerald-100">
                  <Sparkles className="w-4 h-4 text-emerald-600 mx-auto mb-1" />
                  <span className="text-[10px] text-gray-500 block">Care Level</span>
                  <span className="text-[11px] font-bold text-gray-800 truncate block">
                    {selectedProduct.difficulty || 'Easy'}
                  </span>
                </div>
              </div>

              {/* Tabs */}
              <div className="mt-5 border-b border-gray-100 flex space-x-4 text-xs font-bold">
                <button
                  onClick={() => setActiveTab('care')}
                  className={`pb-2 transition ${
                    activeTab === 'care'
                      ? 'border-b-2 border-emerald-600 text-emerald-900'
                      : 'text-gray-400 hover:text-gray-600'
                  }`}
                >
                  Botanical Care Guide
                </button>
                <button
                  onClick={() => setActiveTab('overview')}
                  className={`pb-2 transition ${
                    activeTab === 'overview'
                      ? 'border-b-2 border-emerald-600 text-emerald-900'
                      : 'text-gray-400 hover:text-gray-600'
                  }`}
                >
                  Description
                </button>
              </div>

              {/* Tab Contents */}
              <div className="mt-3 text-xs text-gray-600 leading-relaxed max-h-36 overflow-y-auto pr-1">
                {activeTab === 'care' && selectedProduct.careGuide && (
                  <div className="space-y-2">
                    <p><strong>☀️ Sunlight:</strong> {selectedProduct.careGuide.sunlight}</p>
                    <p><strong>💧 Watering:</strong> {selectedProduct.careGuide.watering}</p>
                    <p><strong>🌱 Soil & Pot:</strong> {selectedProduct.careGuide.soil}</p>
                    <p><strong>🌡️ Temperature:</strong> {selectedProduct.careGuide.temperature}</p>
                    <p><strong>🌿 Fertilizer:</strong> {selectedProduct.careGuide.fertilizer}</p>
                  </div>
                )}

                {activeTab === 'overview' && (
                  <p>{selectedProduct.description}</p>
                )}
              </div>
            </div>

            {/* Action Bar */}
            <div className="pt-3 border-t border-gray-100 space-y-3">
              <div className="flex items-center space-x-3">
                {/* Quantity */}
                <div className="flex items-center space-x-2 border border-gray-200 rounded-xl p-1 bg-gray-50">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="w-7 h-7 flex items-center justify-center rounded-lg text-gray-600 hover:bg-white transition"
                  >
                    <Minus className="w-3.5 h-3.5" />
                  </button>
                  <span className="w-6 text-center text-xs font-bold text-gray-900">{quantity}</span>
                  <button
                    onClick={() => setQuantity(quantity + 1)}
                    className="w-7 h-7 flex items-center justify-center rounded-lg text-gray-600 hover:bg-white transition"
                  >
                    <Plus className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* Add to Cart */}
                <button
                  onClick={handleAddToCart}
                  disabled={selectedProduct.stock <= 0}
                  className="flex-1 bg-emerald-700 hover:bg-emerald-800 disabled:bg-gray-300 text-white font-bold py-3 px-4 rounded-xl shadow-md shadow-emerald-700/20 flex items-center justify-center space-x-2 text-xs transition"
                >
                  <ShoppingCart className="w-4 h-4" />
                  <span>Add to Cart • ${(selectedProduct.price * quantity).toFixed(2)}</span>
                </button>

                {/* Wishlist */}
                <button
                  onClick={() => toggleWishlist(selectedProduct.id)}
                  className={`p-3 rounded-xl border transition ${
                    isFavorited
                      ? 'border-red-200 bg-red-50 text-red-600'
                      : 'border-gray-200 hover:bg-gray-50 text-gray-500'
                  }`}
                  title={isFavorited ? 'Remove from wishlist' : 'Add to wishlist'}
                >
                  <Heart className={`w-4 h-4 ${isFavorited ? 'fill-red-600' : ''}`} />
                </button>
              </div>

              <div className="flex items-center justify-between text-[11px] text-gray-500">
                <span className="flex items-center space-x-1 text-emerald-700">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Free doorstep plant inspection on delivery</span>
                </span>
                <span>Dispatch within 24h</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
