import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { X, Sparkles, Check, ArrowRight, RefreshCw, Sprout } from 'lucide-react';

export const PlantQuizModal = () => {
  const { isQuizOpen, setIsQuizOpen, products, setSelectedProduct } = useApp();

  const [step, setStep] = useState(1);
  const [answers, setAnswers] = useState({
    light: '',
    experience: '',
    petFriendly: ''
  });

  if (!isQuizOpen) return null;

  const handleSelect = (key, value) => {
    setAnswers(prev => ({ ...prev, [key]: value }));
    if (step < 3) {
      setStep(step + 1);
    }
  };

  const getRecommendedPlant = () => {
    if (answers.petFriendly === 'yes') {
      return products.find(p => p.id === 'prod-6') || products[0]; // Areca Palm
    }
    if (answers.experience === 'beginner' || answers.light === 'low') {
      return products.find(p => p.id === 'prod-2') || products[1]; // Snake Plant
    }
    if (answers.light === 'bright') {
      return products.find(p => p.id === 'prod-1') || products[0]; // Monstera
    }
    return products.find(p => p.id === 'prod-3') || products[2]; // Peace Lily
  };

  const recommended = getRecommendedPlant();

  const handleReset = () => {
    setStep(1);
    setAnswers({ light: '', experience: '', petFriendly: '' });
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-lg w-full shadow-2xl overflow-hidden border border-gray-100 p-6 relative">
        <button
          onClick={() => setIsQuizOpen(false)}
          className="absolute right-4 top-4 text-gray-400 hover:text-gray-700"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="text-center mb-6">
          <div className="w-12 h-12 bg-emerald-100 text-emerald-700 rounded-2xl flex items-center justify-center mx-auto mb-2 shadow-xs">
            <Sparkles className="w-6 h-6" />
          </div>
          <h3 className="text-lg font-black text-gray-900">Plant Match Quiz</h3>
          <p className="text-xs text-gray-500">Find the perfect green companion for your space & lifestyle in 3 questions</p>
        </div>

        {/* Step Indicator */}
        <div className="flex items-center justify-center space-x-2 mb-6">
          {[1, 2, 3].map(s => (
            <div
              key={s}
              className={`h-1.5 rounded-full transition-all ${
                step >= s ? 'w-8 bg-emerald-600' : 'w-4 bg-gray-200'
              }`}
            />
          ))}
        </div>

        {/* Question 1: Sunlight */}
        {step === 1 && (
          <div className="space-y-3">
            <h4 className="font-bold text-gray-900 text-sm text-center">
              1. What kind of natural light does your room get?
            </h4>
            <div className="space-y-2 pt-2">
              {[
                { id: 'low', title: 'Dim / Low Light', desc: 'North facing or far from windows' },
                { id: 'indirect', title: 'Bright Indirect Light', desc: 'Sunny room, filtered sheer curtains' },
                { id: 'bright', title: 'Direct Intense Sunlight', desc: 'South/West balcony or sunny sill' }
              ].map(opt => (
                <button
                  key={opt.id}
                  onClick={() => handleSelect('light', opt.id)}
                  className="w-full text-left p-3.5 rounded-2xl border border-gray-200 hover:border-emerald-500 hover:bg-emerald-50/50 transition flex items-center justify-between group"
                >
                  <div>
                    <span className="font-bold text-xs text-gray-800 group-hover:text-emerald-900">
                      {opt.title}
                    </span>
                    <p className="text-[11px] text-gray-500">{opt.desc}</p>
                  </div>
                  <ArrowRight className="w-4 h-4 text-gray-300 group-hover:text-emerald-600 transition" />
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Question 2: Plant Parent Experience */}
        {step === 2 && (
          <div className="space-y-3">
            <h4 className="font-bold text-gray-900 text-sm text-center">
              2. What is your gardening experience level?
            </h4>
            <div className="space-y-2 pt-2">
              {[
                { id: 'beginner', title: 'Total Beginner', desc: 'Need plants that forgive missed waterings' },
                { id: 'intermediate', title: 'Casual Hobbyist', desc: 'Can follow a regular weekly care routine' },
                { id: 'pro', title: 'Green Thumb Enthusiast', desc: 'Love humidity misting, pruning & propagating' }
              ].map(opt => (
                <button
                  key={opt.id}
                  onClick={() => handleSelect('experience', opt.id)}
                  className="w-full text-left p-3.5 rounded-2xl border border-gray-200 hover:border-emerald-500 hover:bg-emerald-50/50 transition flex items-center justify-between group"
                >
                  <div>
                    <span className="font-bold text-xs text-gray-800 group-hover:text-emerald-900">
                      {opt.title}
                    </span>
                    <p className="text-[11px] text-gray-500">{opt.desc}</p>
                  </div>
                  <ArrowRight className="w-4 h-4 text-gray-300 group-hover:text-emerald-600 transition" />
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Question 3: Pets in home */}
        {step === 3 && (
          <div className="space-y-3">
            <h4 className="font-bold text-gray-900 text-sm text-center">
              3. Do you have curious cats or dogs at home?
            </h4>
            <div className="space-y-2 pt-2">
              {[
                { id: 'yes', title: 'Yes, 100% Pet-Friendly Required', desc: 'Must be non-toxic if nibbled by pets' },
                { id: 'no', title: 'No Pets / High Shelves Available', desc: 'Any tropical or statement plant is fine' }
              ].map(opt => (
                <button
                  key={opt.id}
                  onClick={() => {
                    handleSelect('petFriendly', opt.id);
                    setStep(4);
                  }}
                  className="w-full text-left p-3.5 rounded-2xl border border-gray-200 hover:border-emerald-500 hover:bg-emerald-50/50 transition flex items-center justify-between group"
                >
                  <div>
                    <span className="font-bold text-xs text-gray-800 group-hover:text-emerald-900">
                      {opt.title}
                    </span>
                    <p className="text-[11px] text-gray-500">{opt.desc}</p>
                  </div>
                  <ArrowRight className="w-4 h-4 text-gray-300 group-hover:text-emerald-600 transition" />
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Result Screen */}
        {step === 4 && recommended && (
          <div className="text-center space-y-4">
            <span className="text-xs font-bold uppercase tracking-widest text-emerald-800 bg-emerald-100 px-3 py-1 rounded-full">
              Your Perfect Match
            </span>

            <div className="bg-emerald-50/60 p-4 rounded-2xl border border-emerald-100 flex items-center space-x-3 text-left">
              <img
                src={recommended.image}
                alt={recommended.name}
                className="w-20 h-20 rounded-xl object-cover"
              />
              <div>
                <h4 className="font-black text-gray-900 text-sm">{recommended.name}</h4>
                <p className="text-xs text-gray-600 mt-0.5">{recommended.description.slice(0, 85)}...</p>
                <div className="flex items-center space-x-2 mt-2">
                  <span className="font-black text-emerald-700 text-sm">${recommended.price.toFixed(2)}</span>
                  <span className="text-[10px] text-gray-400">by {recommended.nurseryName}</span>
                </div>
              </div>
            </div>

            <div className="flex gap-2">
              <button
                onClick={() => {
                  setIsQuizOpen(false);
                  setSelectedProduct(recommended);
                }}
                className="flex-1 bg-emerald-700 hover:bg-emerald-800 text-white font-bold py-2.5 px-4 rounded-xl text-xs transition"
              >
                View Plant Details & Care
              </button>
              <button
                onClick={handleReset}
                className="p-2.5 rounded-xl border border-gray-200 text-gray-600 hover:bg-gray-50"
                title="Retake Quiz"
              >
                <RefreshCw className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
