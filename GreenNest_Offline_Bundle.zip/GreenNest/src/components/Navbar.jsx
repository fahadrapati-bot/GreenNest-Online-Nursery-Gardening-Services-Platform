import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  Sprout,
  ShoppingCart,
  Bell,
  User,
  Search,
  CheckCircle2,
  Calendar,
  Package,
  RotateCcw,
  Sparkles,
  ChevronDown,
  ShieldCheck,
  Store,
  Compass,
  X
} from 'lucide-react';

export const Navbar = () => {
  const {
    currentRole,
    setCurrentRole,
    cart,
    setIsCartOpen,
    notifications,
    markAllNotificationsRead,
    activeCustomerTab,
    setActiveCustomerTab,
    searchQuery,
    setSearchQuery,
    setIsQuizOpen,
    setIsAuthOpen,
    resetAllData
  } = useApp();

  const [showNotifications, setShowNotifications] = useState(false);
  const [showRoleDropdown, setShowRoleDropdown] = useState(false);

  const cartTotalCount = cart.reduce((acc, item) => acc + item.quantity, 0);
  const unreadNotifCount = notifications.filter(n => !n.isRead).length;

  const roles = [
    {
      id: 'customer',
      label: 'Customer Mode',
      subtitle: 'Aarav Sharma (Bangalore)',
      badge: 'Shopper',
      badgeColor: 'bg-emerald-100 text-emerald-800'
    },
    {
      id: 'vendor',
      label: 'Nursery Vendor',
      subtitle: 'Urbano Nursery & Garden Supplies',
      badge: 'Verified Nursery',
      badgeColor: 'bg-amber-100 text-amber-800'
    },
    {
      id: 'gardener',
      label: 'Gardener Pro',
      subtitle: 'Rajesh Kumar (Horticulture Pro)',
      badge: 'Certified Gardener',
      badgeColor: 'bg-blue-100 text-blue-800'
    },
    {
      id: 'admin',
      label: 'Platform Admin',
      subtitle: 'Unified Mentor Operations',
      badge: 'Super Admin',
      badgeColor: 'bg-purple-100 text-purple-800'
    }
  ];

  const currentRoleObj = roles.find(r => r.id === currentRole) || roles[0];

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur border-b border-emerald-100 shadow-xs">
      {/* Top Utility & Role Bar */}
      <div className="bg-emerald-900 text-emerald-50 text-xs py-1.5 px-4 sm:px-6">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center space-x-2">
            <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-medium bg-emerald-700 text-white">
              🌿 Unified Mentor × Urbano Nursery Platform
            </span>
            <span className="hidden md:inline text-emerald-200">
              Fresh potted plants direct from verified nurseries & certified home gardeners on demand.
            </span>
          </div>

          {/* Quick Role Switcher Bar */}
          <div className="flex items-center space-x-2 ml-auto">
            <span className="text-emerald-300 font-medium hidden sm:inline">Active Persona:</span>
            <div className="relative">
              <button
                onClick={() => setShowRoleDropdown(!showRoleDropdown)}
                className="flex items-center space-x-1.5 bg-emerald-800 hover:bg-emerald-700 text-white px-2.5 py-1 rounded-md text-xs font-semibold transition shadow-xs border border-emerald-600"
              >
                <span>{currentRoleObj.label}</span>
                <ChevronDown className="w-3.5 h-3.5 text-emerald-200" />
              </button>

              {showRoleDropdown && (
                <div className="absolute right-0 mt-1 w-64 bg-white rounded-lg shadow-xl border border-gray-100 py-1.5 z-50 text-gray-800">
                  <div className="px-3 py-1.5 border-b border-gray-100 text-[11px] font-bold text-gray-400 uppercase tracking-wider">
                    Switch Test View (Simulated Roles)
                  </div>
                  {roles.map(r => (
                    <button
                      key={r.id}
                      onClick={() => {
                        setCurrentRole(r.id);
                        setShowRoleDropdown(false);
                      }}
                      className={`w-full text-left px-3 py-2 text-xs flex flex-col hover:bg-emerald-50 transition ${
                        currentRole === r.id ? 'bg-emerald-50/80 font-bold border-l-4 border-emerald-600' : ''
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-emerald-900 font-semibold">{r.label}</span>
                        <span className={`text-[10px] px-1.5 py-0.5 rounded font-medium ${r.badgeColor}`}>
                          {r.badge}
                        </span>
                      </div>
                      <span className="text-[11px] text-gray-500">{r.subtitle}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>

            <button
              onClick={resetAllData}
              title="Reset sample orders, cart, and products"
              className="flex items-center space-x-1 bg-emerald-950/60 hover:bg-emerald-950 px-2 py-1 rounded text-emerald-200 hover:text-white transition"
            >
              <RotateCcw className="w-3 h-3" />
              <span className="hidden sm:inline">Reset Demo</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Navbar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3.5">
        <div className="flex items-center justify-between gap-4">
          {/* Brand Logo */}
          <div
            className="flex items-center space-x-2.5 cursor-pointer select-none group"
            onClick={() => {
              if (currentRole === 'customer') setActiveCustomerTab('shop');
            }}
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-700 to-green-500 flex items-center justify-center text-white shadow-md shadow-emerald-600/20 group-hover:scale-105 transition">
              <Sprout className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center space-x-1">
                <span className="text-2xl font-black tracking-tight text-emerald-950">Green</span>
                <span className="text-2xl font-black tracking-tight text-emerald-600">Nest</span>
                <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-1.5 py-0.5 rounded uppercase tracking-wider">
                  Live
                </span>
              </div>
              <p className="text-[10px] text-emerald-700 font-medium tracking-wide uppercase">
                Online Nursery & Gardening Services
              </p>
            </div>
          </div>

          {/* Search bar (primarily Customer View) */}
          <div className="hidden lg:flex flex-1 max-w-md mx-4">
            <div className="relative w-full">
              <Search className="w-4 h-4 text-emerald-600 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search plants, seeds, planters, or gardening services..."
                value={searchQuery}
                onChange={e => {
                  setSearchQuery(e.target.value);
                  if (currentRole === 'customer' && activeCustomerTab !== 'shop') {
                    setActiveCustomerTab('shop');
                  }
                }}
                className="w-full bg-emerald-50/70 hover:bg-emerald-50 focus:bg-white text-sm text-gray-800 pl-10 pr-8 py-2 rounded-full border border-emerald-200 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-hidden transition"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>

          {/* Role specific Navigation buttons */}
          <nav className="flex items-center space-x-2 sm:space-x-3">
            {currentRole === 'customer' && (
              <>
                <div className="hidden md:flex items-center space-x-1 bg-emerald-50/80 p-1 rounded-xl border border-emerald-100">
                  <button
                    onClick={() => setActiveCustomerTab('shop')}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center space-x-1.5 ${
                      activeCustomerTab === 'shop'
                        ? 'bg-emerald-700 text-white shadow-xs'
                        : 'text-emerald-900 hover:bg-emerald-100/60'
                    }`}
                  >
                    <Sprout className="w-3.5 h-3.5" />
                    <span>Catalog & Nursery</span>
                  </button>

                  <button
                    onClick={() => setActiveCustomerTab('services')}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center space-x-1.5 ${
                      activeCustomerTab === 'services'
                        ? 'bg-emerald-700 text-white shadow-xs'
                        : 'text-emerald-900 hover:bg-emerald-100/60'
                    }`}
                  >
                    <Calendar className="w-3.5 h-3.5" />
                    <span>Gardener Booking</span>
                  </button>

                  <button
                    onClick={() => setActiveCustomerTab('orders')}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center space-x-1.5 ${
                      activeCustomerTab === 'orders'
                        ? 'bg-emerald-700 text-white shadow-xs'
                        : 'text-emerald-900 hover:bg-emerald-100/60'
                    }`}
                  >
                    <Package className="w-3.5 h-3.5" />
                    <span>My Orders</span>
                  </button>

                  <button
                    onClick={() => setActiveCustomerTab('bookings')}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center space-x-1.5 ${
                      activeCustomerTab === 'bookings'
                        ? 'bg-emerald-700 text-white shadow-xs'
                        : 'text-emerald-900 hover:bg-emerald-100/60'
                    }`}
                  >
                    <ShieldCheck className="w-3.5 h-3.5" />
                    <span>My Bookings</span>
                  </button>
                </div>

                <button
                  onClick={() => setIsQuizOpen(true)}
                  className="hidden xl:flex items-center space-x-1.5 bg-gradient-to-r from-emerald-50 to-teal-50 hover:from-emerald-100 hover:to-teal-100 text-emerald-800 text-xs font-semibold px-3 py-1.5 rounded-full border border-emerald-200 transition"
                >
                  <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Plant Match Quiz</span>
                </button>
              </>
            )}

            {currentRole === 'vendor' && (
              <div className="flex items-center space-x-1.5 bg-amber-50 px-3 py-1.5 rounded-lg border border-amber-200 text-amber-900 text-xs font-bold">
                <Store className="w-4 h-4 text-amber-700" />
                <span>Urbano Nursery Console</span>
              </div>
            )}

            {currentRole === 'gardener' && (
              <div className="flex items-center space-x-1.5 bg-blue-50 px-3 py-1.5 rounded-lg border border-blue-200 text-blue-900 text-xs font-bold">
                <ShieldCheck className="w-4 h-4 text-blue-700" />
                <span>Gardener Pro Schedule</span>
              </div>
            )}

            {currentRole === 'admin' && (
              <div className="flex items-center space-x-1.5 bg-purple-50 px-3 py-1.5 rounded-lg border border-purple-200 text-purple-900 text-xs font-bold">
                <Compass className="w-4 h-4 text-purple-700" />
                <span>Unified Mentor Admin</span>
              </div>
            )}

            {/* Notification Center */}
            <div className="relative">
              <button
                onClick={() => setShowNotifications(!showNotifications)}
                aria-label="View notifications"
                className="relative p-2 rounded-xl text-gray-700 hover:text-emerald-800 hover:bg-emerald-50 transition border border-transparent hover:border-emerald-200"
              >
                <Bell className="w-5 h-5" />
                {unreadNotifCount > 0 && (
                  <span className="absolute top-1 right-1 w-4 h-4 rounded-full bg-emerald-600 text-white text-[10px] font-bold flex items-center justify-center animate-pulse">
                    {unreadNotifCount}
                  </span>
                )}
              </button>

              {showNotifications && (
                <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-white rounded-2xl shadow-2xl border border-gray-100 py-3 z-50 animate-in fade-in zoom-in-95">
                  <div className="flex items-center justify-between px-4 pb-2 border-b border-gray-100">
                    <div className="flex items-center space-x-2">
                      <span className="font-bold text-gray-900 text-sm">Notifications</span>
                      <span className="text-[10px] font-semibold bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full">
                        {notifications.length} alerts
                      </span>
                    </div>
                    {unreadNotifCount > 0 && (
                      <button
                        onClick={markAllNotificationsRead}
                        className="text-xs text-emerald-700 hover:text-emerald-900 font-semibold"
                      >
                        Mark all read
                      </button>
                    )}
                  </div>
                  <div className="max-h-80 overflow-y-auto divide-y divide-gray-50">
                    {notifications.length === 0 ? (
                      <p className="text-center py-6 text-gray-400 text-xs">No notifications yet.</p>
                    ) : (
                      notifications.map(n => (
                        <div
                          key={n.id}
                          className={`p-3 text-xs transition hover:bg-gray-50 ${
                            !n.isRead ? 'bg-emerald-50/40 font-medium' : ''
                          }`}
                        >
                          <div className="flex items-start justify-between gap-2">
                            <h4 className="font-bold text-gray-900">{n.title}</h4>
                            <span className="text-[10px] text-gray-400 shrink-0">{n.time}</span>
                          </div>
                          <p className="text-gray-600 mt-1">{n.message}</p>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Cart Button (Customer View) */}
            {currentRole === 'customer' && (
              <button
                onClick={() => setIsCartOpen(true)}
                className="relative flex items-center space-x-2 bg-emerald-700 hover:bg-emerald-800 text-white px-3 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-bold shadow-md shadow-emerald-700/20 transition group"
              >
                <ShoppingCart className="w-4 h-4 group-hover:scale-110 transition" />
                <span className="hidden sm:inline">Cart</span>
                <span className="w-5 h-5 rounded-full bg-emerald-900 text-white text-xs flex items-center justify-center font-extrabold">
                  {cartTotalCount}
                </span>
              </button>
            )}

            {/* Profile / Auth */}
            <button
              onClick={() => setIsAuthOpen(true)}
              aria-label="User profile and login"
              className="p-2 rounded-xl text-gray-700 hover:text-emerald-800 hover:bg-emerald-50 transition border border-gray-200"
              title={`Logged in as ${currentRoleObj.label}`}
            >
              <User className="w-5 h-5" />
            </button>
          </nav>
        </div>

        {/* Mobile Search Bar */}
        <div className="lg:hidden mt-3">
          <div className="relative w-full">
            <Search className="w-4 h-4 text-emerald-600 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search plants, tools, gardeners..."
              value={searchQuery}
              onChange={e => {
                setSearchQuery(e.target.value);
                if (currentRole === 'customer' && activeCustomerTab !== 'shop') {
                  setActiveCustomerTab('shop');
                }
              }}
              className="w-full bg-emerald-50/70 text-xs text-gray-800 pl-9 pr-4 py-2 rounded-full border border-emerald-200 focus:outline-hidden"
            />
          </div>
        </div>

        {/* Mobile Customer Tabs */}
        {currentRole === 'customer' && (
          <div className="flex md:hidden items-center justify-between space-x-1 mt-2.5 overflow-x-auto py-1 scrollbar-none">
            <button
              onClick={() => setActiveCustomerTab('shop')}
              className={`px-3 py-1 rounded-lg text-xs font-bold whitespace-nowrap ${
                activeCustomerTab === 'shop' ? 'bg-emerald-700 text-white' : 'bg-emerald-50 text-emerald-900'
              }`}
            >
              Shop
            </button>
            <button
              onClick={() => setActiveCustomerTab('services')}
              className={`px-3 py-1 rounded-lg text-xs font-bold whitespace-nowrap ${
                activeCustomerTab === 'services' ? 'bg-emerald-700 text-white' : 'bg-emerald-50 text-emerald-900'
              }`}
            >
              Gardener
            </button>
            <button
              onClick={() => setActiveCustomerTab('orders')}
              className={`px-3 py-1 rounded-lg text-xs font-bold whitespace-nowrap ${
                activeCustomerTab === 'orders' ? 'bg-emerald-700 text-white' : 'bg-emerald-50 text-emerald-900'
              }`}
            >
              Orders ({cartTotalCount > 0 ? cartTotalCount : 2})
            </button>
            <button
              onClick={() => setActiveCustomerTab('bookings')}
              className={`px-3 py-1 rounded-lg text-xs font-bold whitespace-nowrap ${
                activeCustomerTab === 'bookings' ? 'bg-emerald-700 text-white' : 'bg-emerald-50 text-emerald-900'
              }`}
            >
              Bookings
            </button>
            <button
              onClick={() => setIsQuizOpen(true)}
              className="px-3 py-1 rounded-lg text-xs font-bold whitespace-nowrap bg-teal-50 text-teal-800 flex items-center space-x-1"
            >
              <Sparkles className="w-3 h-3 text-teal-600" />
              <span>Quiz</span>
            </button>
          </div>
        )}
      </div>
    </header>
  );
};
