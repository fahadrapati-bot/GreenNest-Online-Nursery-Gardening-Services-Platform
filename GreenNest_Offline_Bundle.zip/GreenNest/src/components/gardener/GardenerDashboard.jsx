import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Calendar,
  Clock,
  MapPin,
  Phone,
  CheckCircle,
  Star,
  ShieldCheck,
  ToggleLeft,
  ToggleRight,
  User,
  DollarSign,
  Briefcase
} from 'lucide-react';

export const GardenerDashboard = () => {
  const {
    bookings,
    updateBookingStatus,
    gardeners,
    toggleGardenerStatus
  } = useApp();

  const gardener = gardeners.find(g => g.id === 'gardener-1') || gardeners[0];
  const isAvailable = gardener.status === 'Available Today';

  const rajeshBookings = bookings.filter(b => b.gardenerName.includes('Rajesh'));

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-blue-950 via-slate-900 to-emerald-950 text-white rounded-3xl p-6 sm:p-8 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center space-x-4">
            <img
              src={gardener.image}
              alt={gardener.name}
              className="w-16 h-16 rounded-2xl object-cover border-2 border-blue-400/40 shadow-lg"
            />
            <div>
              <div className="flex items-center space-x-2">
                <h1 className="text-2xl font-black">{gardener.name}</h1>
                <span className="bg-blue-500 text-white text-[10px] font-bold px-2 py-0.5 rounded-full">
                  Certified Pro
                </span>
              </div>
              <p className="text-xs text-blue-200 mt-0.5">{gardener.title}</p>
              <div className="flex items-center space-x-2 mt-1 text-xs text-blue-300">
                <span className="flex items-center space-x-1 text-amber-400 font-bold">
                  <Star className="w-3.5 h-3.5 fill-amber-400" />
                  <span>{gardener.rating}</span>
                </span>
                <span>•</span>
                <span>{gardener.completedJobs} Completed Appointments</span>
              </div>
            </div>
          </div>

          {/* Availability Toggle */}
          <div className="bg-blue-900/40 p-4 rounded-2xl border border-blue-800/60 flex items-center space-x-3">
            <div>
              <span className="text-xs font-bold block text-white">Booking Status:</span>
              <span className={`text-[11px] ${isAvailable ? 'text-green-400' : 'text-amber-300'}`}>
                {isAvailable ? 'Open for new appointments' : 'Marked as Off-Duty'}
              </span>
            </div>
            <button
              onClick={() => toggleGardenerStatus(gardener.id)}
              className="text-blue-300 hover:text-white transition"
              title="Toggle status"
            >
              {isAvailable ? (
                <ToggleRight className="w-8 h-8 text-emerald-400" />
              ) : (
                <ToggleLeft className="w-8 h-8 text-gray-400" />
              )}
            </button>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-6 pt-6 border-t border-blue-800/60 text-xs">
          <div className="bg-blue-900/30 p-3 rounded-xl border border-blue-800/30">
            <span className="text-blue-300">Standard Rate</span>
            <span className="text-xl font-black text-white block mt-1">${gardener.hourlyRate}/hr</span>
          </div>
          <div className="bg-blue-900/30 p-3 rounded-xl border border-blue-800/30">
            <span className="text-blue-300">Scheduled Visits</span>
            <span className="text-xl font-black text-white block mt-1">{rajeshBookings.length}</span>
          </div>
          <div className="bg-blue-900/30 p-3 rounded-xl border border-blue-800/30">
            <span className="text-blue-300">Total Client Rating</span>
            <span className="text-xl font-black text-amber-400 block mt-1">4.95 ★</span>
          </div>
          <div className="bg-blue-900/30 p-3 rounded-xl border border-blue-800/30">
            <span className="text-blue-300">Estimated Earnings</span>
            <span className="text-xl font-black text-emerald-300 block mt-1">
              ${(rajeshBookings.reduce((acc, b) => acc + b.price, 0) + 1240).toFixed(2)}
            </span>
          </div>
        </div>
      </div>

      {/* Bookings Schedule List */}
      <div className="bg-white rounded-3xl p-6 border border-gray-100 shadow-xs space-y-4">
        <div>
          <h3 className="font-bold text-gray-900 text-base">Assigned Service Appointments</h3>
          <p className="text-xs text-gray-500">Manage client site visits, update progress, and log completion</p>
        </div>

        <div className="space-y-4">
          {rajeshBookings.length === 0 ? (
            <p className="text-xs text-gray-500 text-center py-8">No assigned visits scheduled currently.</p>
          ) : (
            rajeshBookings.map(bkg => (
              <div
                key={bkg.id}
                className="p-5 rounded-2xl border border-gray-200 bg-gray-50/50 space-y-4"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-gray-200 gap-2">
                  <div>
                    <div className="flex items-center space-x-2">
                      <span className="font-black text-gray-900 text-xs">{bkg.id}</span>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        bkg.status === 'Completed'
                          ? 'bg-green-100 text-green-800'
                          : bkg.status === 'In Progress'
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-blue-100 text-blue-800'
                      }`}>
                        {bkg.status}
                      </span>
                    </div>
                    <h4 className="font-bold text-gray-900 text-sm mt-0.5">{bkg.serviceName}</h4>
                  </div>

                  <div className="flex items-center space-x-2">
                    <span className="text-xs text-gray-400">Action:</span>
                    {bkg.status === 'Confirmed' && (
                      <button
                        onClick={() => updateBookingStatus(bkg.id, 'In Progress')}
                        className="bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold px-3 py-1.5 rounded-lg transition"
                      >
                        Start Visit
                      </button>
                    )}
                    {bkg.status === 'In Progress' && (
                      <button
                        onClick={() => updateBookingStatus(bkg.id, 'Completed')}
                        className="bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold px-3 py-1.5 rounded-lg transition"
                      >
                        Mark Completed
                      </button>
                    )}
                    {bkg.status === 'Completed' && (
                      <span className="text-xs font-bold text-emerald-700 flex items-center space-x-1">
                        <CheckCircle className="w-3.5 h-3.5" />
                        <span>Finished</span>
                      </span>
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                  <div>
                    <span className="text-gray-400 block mb-0.5">Client & Contact</span>
                    <span className="font-bold text-gray-800 block">{bkg.customerName}</span>
                    <span className="text-emerald-700 flex items-center space-x-1 mt-0.5">
                      <Phone className="w-3 h-3" />
                      <span>{bkg.customerPhone}</span>
                    </span>
                  </div>

                  <div>
                    <span className="text-gray-400 block mb-0.5">Scheduled Slot</span>
                    <span className="font-bold text-gray-800 block">{bkg.date}</span>
                    <span className="text-gray-600 flex items-center space-x-1 mt-0.5">
                      <Clock className="w-3 h-3" />
                      <span>{bkg.timeSlot}</span>
                    </span>
                  </div>

                  <div>
                    <span className="text-gray-400 block mb-0.5">Client Notes</span>
                    <p className="text-gray-600 italic">{bkg.notes || 'Routine maintenance'}</p>
                  </div>
                </div>

                <div className="text-xs text-gray-500 pt-2 border-t border-gray-200 flex items-center space-x-1">
                  <MapPin className="w-3.5 h-3.5 text-gray-400" />
                  <span>{bkg.address}</span>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
