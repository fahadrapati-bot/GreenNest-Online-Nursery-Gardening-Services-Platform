import React from 'react';
import { Sprout, ShieldCheck, HeartHandshake, Truck, RefreshCw, Mail, Phone, MapPin } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const Footer = () => {
  const { setCurrentRole, setActiveCustomerTab } = useApp();

  return (
    <footer className="bg-emerald-950 text-emerald-100 pt-14 pb-8 border-t border-emerald-900 mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Value Highlights */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 pb-12 border-b border-emerald-900/60">
          <div className="flex items-center space-x-3 bg-emerald-900/30 p-4 rounded-xl border border-emerald-800/40">
            <div className="p-2.5 rounded-lg bg-emerald-800/80 text-emerald-300">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-white font-bold text-sm">Safe Eco-Transit</h4>
              <p className="text-xs text-emerald-300/80">Breathable packaging guaranteed</p>
            </div>
          </div>

          <div className="flex items-center space-x-3 bg-emerald-900/30 p-4 rounded-xl border border-emerald-800/40">
            <div className="p-2.5 rounded-lg bg-emerald-800/80 text-emerald-300">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-white font-bold text-sm">Verified Gardeners</h4>
              <p className="text-xs text-emerald-300/80">Background checked & rated</p>
            </div>
          </div>

          <div className="flex items-center space-x-3 bg-emerald-900/30 p-4 rounded-xl border border-emerald-800/40">
            <div className="p-2.5 rounded-lg bg-emerald-800/80 text-emerald-300">
              <RefreshCw className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-white font-bold text-sm">7-Day Healthy Plant Guarantee</h4>
              <p className="text-xs text-emerald-300/80">Free replacement if unhealthy</p>
            </div>
          </div>

          <div className="flex items-center space-x-3 bg-emerald-900/30 p-4 rounded-xl border border-emerald-800/40">
            <div className="p-2.5 rounded-lg bg-emerald-800/80 text-emerald-300">
              <HeartHandshake className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-white font-bold text-sm">Support Local Nurseries</h4>
              <p className="text-xs text-emerald-300/80">Direct from Urbano & partners</p>
            </div>
          </div>
        </div>

        {/* Main Footer Links */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-8 py-12">
          {/* Col 1: About */}
          <div className="md:col-span-2 space-y-4">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 rounded-lg bg-emerald-600 flex items-center justify-center text-white shadow-md">
                <Sprout className="w-5 h-5" />
              </div>
              <span className="text-xl font-black tracking-tight text-white">GreenNest</span>
            </div>
            <p className="text-xs text-emerald-300/90 leading-relaxed max-w-sm">
              GreenNest is a centralized digital ecosystem connecting urban plant lovers with trusted local nurseries and certified gardening professionals. Nurture your green space with ease, transparency, and expert care.
            </p>
            <div className="pt-2 flex flex-col space-y-2 text-xs text-emerald-300">
              <span className="flex items-center space-x-2">
                <MapPin className="w-3.5 h-3.5 text-emerald-400" />
                <span>Urbano Nursery & Partner Hubs, Indiranagar, Bengaluru</span>
              </span>
              <span className="flex items-center space-x-2">
                <Phone className="w-3.5 h-3.5 text-emerald-400" />
                <span>+91 80 4912 8800 (Mon - Sat, 8 AM - 8 PM)</span>
              </span>
              <span className="flex items-center space-x-2">
                <Mail className="w-3.5 h-3.5 text-emerald-400" />
                <span>support@greennest.unifiedmentor.com</span>
              </span>
            </div>
          </div>

          {/* Col 2: Shop Categories */}
          <div className="space-y-3">
            <h4 className="text-sm font-bold text-white uppercase tracking-wider">Catalog</h4>
            <ul className="space-y-2 text-xs text-emerald-300/80">
              <li>
                <button
                  onClick={() => {
                    setCurrentRole('customer');
                    setActiveCustomerTab('shop');
                  }}
                  className="hover:text-white transition"
                >
                  Indoor Air Purifiers
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    setCurrentRole('customer');
                    setActiveCustomerTab('shop');
                  }}
                  className="hover:text-white transition"
                >
                  Flowering Balcony Plants
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    setCurrentRole('customer');
                    setActiveCustomerTab('shop');
                  }}
                  className="hover:text-white transition"
                >
                  Culinary Herb Seeds
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    setCurrentRole('customer');
                    setActiveCustomerTab('shop');
                  }}
                  className="hover:text-white transition"
                >
                  Terracotta Planters
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    setCurrentRole('customer');
                    setActiveCustomerTab('shop');
                  }}
                  className="hover:text-white transition"
                >
                  Organic Vermicompost
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Gardener Services */}
          <div className="space-y-3">
            <h4 className="text-sm font-bold text-white uppercase tracking-wider">Services</h4>
            <ul className="space-y-2 text-xs text-emerald-300/80">
              <li>
                <button
                  onClick={() => {
                    setCurrentRole('customer');
                    setActiveCustomerTab('services');
                  }}
                  className="hover:text-white transition"
                >
                  Home Gardening & Maintenance
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    setCurrentRole('customer');
                    setActiveCustomerTab('services');
                  }}
                  className="hover:text-white transition"
                >
                  Lawn Mowing & Turf Care
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    setCurrentRole('customer');
                    setActiveCustomerTab('services');
                  }}
                  className="hover:text-white transition"
                >
                  Plant Health & Pest Cure
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    setCurrentRole('customer');
                    setActiveCustomerTab('services');
                  }}
                  className="hover:text-white transition"
                >
                  Balcony Garden Consultation
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    setCurrentRole('customer');
                    setActiveCustomerTab('services');
                  }}
                  className="hover:text-white transition"
                >
                  Seasonal Repotting & Soil Prep
                </button>
              </li>
            </ul>
          </div>

          {/* Col 4: Platform Portals */}
          <div className="space-y-3">
            <h4 className="text-sm font-bold text-white uppercase tracking-wider">Stakeholder Consoles</h4>
            <ul className="space-y-2 text-xs text-emerald-300/80">
              <li>
                <button onClick={() => setCurrentRole('customer')} className="hover:text-white transition">
                  👤 Customer Hub (Orders & Bookings)
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentRole('vendor')} className="hover:text-white transition">
                  🏡 Urbano Nursery Vendor Console
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentRole('gardener')} className="hover:text-white transition">
                  👨‍🌾 Gardener Pro Portal
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentRole('admin')} className="hover:text-white transition">
                  ⚙️ Unified Mentor Admin Operations
                </button>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-emerald-900/60 flex flex-col sm:flex-row items-center justify-between text-xs text-emerald-400/80 gap-3">
          <p>© 2026 GreenNest Platform. Crafted for Unified Mentor & Urbano Nursery Project Requirements.</p>
          <div className="flex space-x-4">
            <span className="hover:text-white cursor-pointer">Eco-Policy</span>
            <span>•</span>
            <span className="hover:text-white cursor-pointer">Privacy & Verification Terms</span>
            <span>•</span>
            <span className="hover:text-white cursor-pointer">Gardener Code of Conduct</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
