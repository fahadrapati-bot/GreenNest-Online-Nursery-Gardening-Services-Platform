import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { X, Sprout, Store, ShieldCheck, UserCheck, CheckCircle2 } from 'lucide-react';

export const AuthModal = () => {
  const { isAuthOpen, setIsAuthOpen, currentRole, setCurrentRole, showToast } = useApp();
  const [tab, setTab] = useState('login'); // 'login' | 'register'
  const [selectedRole, setSelectedRole] = useState(currentRole);

  const [form, setForm] = useState({
    name: 'Aarav Sharma',
    email: 'aarav.sharma@example.com',
    password: '••••••••',
    businessName: 'Urbano Nursery Indiranagar',
    phone: '+91 98765 43210'
  });

  if (!isAuthOpen) return null;

  const handleSubmit = (e) => {
    e.preventDefault();
    setCurrentRole(selectedRole);
    setIsAuthOpen(false);
    showToast(
      tab === 'login'
        ? `Logged in successfully as ${selectedRole.toUpperCase()}!`
        : `Account created for ${form.name}! Switched to ${selectedRole.toUpperCase()} view.`
    );
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-md w-full shadow-2xl overflow-hidden border border-gray-100 p-6 relative">
        <button
          onClick={() => setIsAuthOpen(false)}
          className="absolute right-4 top-4 text-gray-400 hover:text-gray-700"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="text-center mb-5">
          <div className="w-10 h-10 bg-emerald-100 text-emerald-700 rounded-xl flex items-center justify-center mx-auto mb-2">
            <Sprout className="w-5 h-5" />
          </div>
          <h3 className="text-lg font-black text-gray-900">GreenNest Account</h3>
          <p className="text-xs text-gray-500">Access orders, inventory console & booking schedules</p>
        </div>

        {/* Tab switch */}
        <div className="flex bg-gray-100 p-1 rounded-xl mb-4 text-xs font-bold">
          <button
            onClick={() => setTab('login')}
            className={`flex-1 py-1.5 rounded-lg transition ${
              tab === 'login' ? 'bg-white text-emerald-900 shadow-xs' : 'text-gray-500'
            }`}
          >
            Sign In
          </button>
          <button
            onClick={() => setTab('register')}
            className={`flex-1 py-1.5 rounded-lg transition ${
              tab === 'register' ? 'bg-white text-emerald-900 shadow-xs' : 'text-gray-500'
            }`}
          >
            Create Account
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          {/* Persona selector */}
          <div>
            <label className="block text-gray-700 font-semibold mb-1.5">Select Your Portal Role</label>
            <div className="grid grid-cols-3 gap-2">
              {[
                { id: 'customer', label: 'Customer', icon: UserCheck },
                { id: 'vendor', label: 'Nursery', icon: Store },
                { id: 'gardener', label: 'Gardener', icon: ShieldCheck }
              ].map(r => {
                const Icon = r.icon;
                return (
                  <button
                    key={r.id}
                    type="button"
                    onClick={() => setSelectedRole(r.id)}
                    className={`p-2.5 rounded-xl border text-center transition flex flex-col items-center justify-center space-y-1 ${
                      selectedRole === r.id
                        ? 'border-emerald-600 bg-emerald-50 text-emerald-900 font-bold ring-1 ring-emerald-600'
                        : 'border-gray-200 text-gray-600 hover:bg-gray-50'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                    <span className="text-[11px]">{r.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {tab === 'register' && (
            <div>
              <label className="block text-gray-600 mb-1 font-medium">Full Name / Contact Person</label>
              <input
                type="text"
                required
                value={form.name}
                onChange={e => setForm({ ...form, name: e.target.value })}
                className="w-full p-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:bg-white focus:outline-hidden focus:border-emerald-500"
              />
            </div>
          )}

          {tab === 'register' && selectedRole === 'vendor' && (
            <div>
              <label className="block text-gray-600 mb-1 font-medium">Nursery Business Name</label>
              <input
                type="text"
                required
                value={form.businessName}
                onChange={e => setForm({ ...form, businessName: e.target.value })}
                className="w-full p-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:bg-white focus:outline-hidden focus:border-emerald-500"
              />
            </div>
          )}

          <div>
            <label className="block text-gray-600 mb-1 font-medium">Email Address</label>
            <input
              type="email"
              required
              value={form.email}
              onChange={e => setForm({ ...form, email: e.target.value })}
              className="w-full p-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:bg-white focus:outline-hidden focus:border-emerald-500"
            />
          </div>

          <div>
            <label className="block text-gray-600 mb-1 font-medium">Password</label>
            <input
              type="password"
              required
              value={form.password}
              onChange={e => setForm({ ...form, password: e.target.value })}
              className="w-full p-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:bg-white focus:outline-hidden focus:border-emerald-500"
            />
          </div>

          <button
            type="submit"
            className="w-full bg-emerald-700 hover:bg-emerald-800 text-white font-bold py-3 rounded-xl shadow-md shadow-emerald-700/20 text-xs transition"
          >
            {tab === 'login' ? `Sign In as ${selectedRole.toUpperCase()}` : `Register as ${selectedRole.toUpperCase()}`}
          </button>
        </form>

        <div className="mt-4 pt-3 border-t border-gray-100 text-center">
          <p className="text-[11px] text-gray-400">
            For demonstration, you can also toggle roles instantly using the top banner.
          </p>
        </div>
      </div>
    </div>
  );
};
