// GreenNest Initial Seed Data

export const INITIAL_CATEGORIES = [
  { id: 'all', name: 'All Items', icon: 'Sparkles' },
  { id: 'indoor', name: 'Indoor Plants', icon: 'Home' },
  { id: 'outdoor', name: 'Outdoor Plants', icon: 'Sun' },
  { id: 'flowering', name: 'Flowering Plants', icon: 'Flower2' },
  { id: 'seeds', name: 'Seeds & Bulbs', icon: 'Sprout' },
  { id: 'pots', name: 'Pots & Planters', icon: 'Box' },
  { id: 'tools', name: 'Gardening Tools', icon: 'Wrench' },
  { id: 'care', name: 'Fertilizers & Soil', icon: 'Droplets' },
];

export const INITIAL_PRODUCTS = [
  {
    id: 'prod-1',
    name: 'Monstera Deliciosa (Swiss Cheese Plant)',
    botanicalName: 'Monstera deliciosa',
    category: 'indoor',
    type: 'Indoor Plant',
    price: 34.99,
    originalPrice: 42.00,
    rating: 4.9,
    reviewsCount: 142,
    stock: 28,
    nurseryId: 'nursery-1',
    nurseryName: 'Urbano Nursery',
    isIndoor: true,
    isOutdoor: false,
    light: 'Indirect Bright Light',
    water: 'Every 1-2 weeks',
    difficulty: 'Easy',
    petFriendly: false,
    image: 'https://images.unsplash.com/photo-1614594975525-e45190c55d0b?auto=format&fit=crop&w=800&q=80',
    tags: ['Bestseller', 'Air Purifying', 'Statement Plant'],
    description: 'Known for its iconic natural leaf holes, the Monstera Deliciosa is a vibrant, easy-to-care-for tropical plant that adds instant lush greenery to any living room or office.',
    careGuide: {
      sunlight: 'Prefers bright, indirect sunlight. Can adapt to medium light, but growth may slow.',
      watering: 'Water when top 2-3 inches of soil are dry. Ensure good drainage to prevent root rot.',
      soil: 'Rich, well-draining organic potting mix with perlite or peat moss.',
      temperature: '65°F - 85°F (18°C - 30°C). Protect from cold drafts below 55°F.',
      fertilizer: 'Feed once a month during spring and summer with balanced houseplant fertilizer.'
    }
  },
  {
    id: 'prod-2',
    name: 'Sansevieria Trifasciata (Snake Plant)',
    botanicalName: 'Dracaena trifasciata',
    category: 'indoor',
    type: 'Indoor Plant',
    price: 24.50,
    originalPrice: 29.99,
    rating: 4.8,
    reviewsCount: 98,
    stock: 45,
    nurseryId: 'nursery-1',
    nurseryName: 'Urbano Nursery',
    isIndoor: true,
    isOutdoor: false,
    light: 'Low to Bright Light',
    water: 'Every 2-3 weeks',
    difficulty: 'Very Easy',
    petFriendly: false,
    image: 'https://images.unsplash.com/photo-1593482892290-f54927ae1bf6?auto=format&fit=crop&w=800&q=80',
    tags: ['Low Maintenance', 'NASA Air Purifier', 'Drought Hardy'],
    description: 'Indestructible and architectural. The Snake Plant purifies indoor air around the clock by converting CO2 into oxygen at night.',
    careGuide: {
      sunlight: 'Extremely adaptable: thrives in low light to full indirect sun.',
      watering: 'Infrequent watering. Allow soil to dry out completely between waterings.',
      soil: 'Free-draining succulent or cactus mix.',
      temperature: '60°F - 85°F (15°C - 29°C).',
      fertilizer: 'Light liquid fertilizer 1-2 times during active summer growth.'
    }
  },
  {
    id: 'prod-3',
    name: 'Peace Lily (Spathiphyllum)',
    botanicalName: 'Spathiphyllum wallisii',
    category: 'flowering',
    type: 'Flowering Indoor',
    price: 28.00,
    originalPrice: 35.00,
    rating: 4.7,
    reviewsCount: 76,
    stock: 19,
    nurseryId: 'nursery-1',
    nurseryName: 'Urbano Nursery',
    isIndoor: true,
    isOutdoor: false,
    light: 'Medium Indirect Light',
    water: 'Once a week',
    difficulty: 'Easy',
    petFriendly: false,
    image: 'https://images.unsplash.com/photo-1593691509543-c55fb32e7355?auto=format&fit=crop&w=800&q=80',
    tags: ['Flowering', 'Air Purifying', 'Tells You When Thirsty'],
    description: 'Elegant white spathes rise above glossy emerald leaves. It will droop gently when it needs water and perk right back up after a drink.',
    careGuide: {
      sunlight: 'Medium to low indirect light. Avoid direct harsh rays.',
      watering: 'Keep soil consistently moist but never soggy. Loves misting.',
      soil: 'Rich peat-based potting soil.',
      temperature: '68°F - 85°F (20°C - 30°C).',
      fertilizer: 'Balanced organic fertilizer every 6 weeks during bloom season.'
    }
  },
  {
    id: 'prod-4',
    name: 'Bougainvillea Glabra (Paper Flower)',
    botanicalName: 'Bougainvillea glabra',
    category: 'flowering',
    type: 'Outdoor Flowering',
    price: 32.00,
    originalPrice: 38.00,
    rating: 4.8,
    reviewsCount: 64,
    stock: 22,
    nurseryId: 'nursery-2',
    nurseryName: 'Green Eden Botanicals',
    isIndoor: false,
    isOutdoor: true,
    light: 'Full Direct Sun',
    water: 'Moderate',
    difficulty: 'Medium',
    petFriendly: true,
    image: 'https://images.unsplash.com/photo-1516205651411-aef33a44f7c2?auto=format&fit=crop&w=800&q=80',
    tags: ['Outdoor Showstopper', 'Vibrant Blooms', 'Sun Loving'],
    description: 'Magnificent climbing shrub producing cascades of vivid magenta paper-like flower bracts. Perfect for patios, trellises, and sunny balconies.',
    careGuide: {
      sunlight: 'At least 6+ hours of full direct sunlight daily for profuse flowering.',
      watering: 'Drought tolerant once established. Water when top 2 inches dry out.',
      soil: 'Well-draining loamy or sandy soil with neutral pH.',
      temperature: 'Thrives in warm tropical & Mediterranean climates (70°F+).',
      fertilizer: 'High-potassium fertilizer every 3 weeks in summer for maximum blossoms.'
    }
  },
  {
    id: 'prod-5',
    name: 'Fiddle Leaf Fig (Ficus Lyrata)',
    botanicalName: 'Ficus lyrata',
    category: 'indoor',
    type: 'Indoor Tree',
    price: 49.99,
    originalPrice: 65.00,
    rating: 4.6,
    reviewsCount: 110,
    stock: 14,
    nurseryId: 'nursery-1',
    nurseryName: 'Urbano Nursery',
    isIndoor: true,
    isOutdoor: false,
    light: 'Bright Filtered Sun',
    water: 'Every 7-10 days',
    difficulty: 'Medium',
    petFriendly: false,
    image: 'https://images.unsplash.com/photo-1545241047-6083a3684587?auto=format&fit=crop&w=800&q=80',
    tags: ['Designer Favorite', 'Architectural Foliage'],
    description: 'The premier statement plant for modern interior spaces, featuring broad violin-shaped leaves that create an imposing architectural presence.',
    careGuide: {
      sunlight: 'Needs abundant bright, indirect light near a south or east window.',
      watering: 'Water thoroughly once the top inch is dry until water runs through.',
      soil: 'Nutrient-rich, well-aerated potting mix.',
      temperature: '65°F - 75°F. Keep away from air conditioning vents and cold spots.',
      fertilizer: 'Diluted nitrogen-rich houseplant fertilizer every month in spring.'
    }
  },
  {
    id: 'prod-6',
    name: 'Areca Palm (Chrysalidocarpus Lutescens)',
    botanicalName: 'Dypsis lutescens',
    category: 'indoor',
    type: 'Indoor & Semi-Outdoor',
    price: 39.50,
    originalPrice: 48.00,
    rating: 4.7,
    reviewsCount: 89,
    stock: 17,
    nurseryId: 'nursery-2',
    nurseryName: 'Green Eden Botanicals',
    isIndoor: true,
    isOutdoor: true,
    light: 'Bright Indirect Light',
    water: '2 times a week',
    difficulty: 'Easy',
    petFriendly: true,
    image: 'https://images.unsplash.com/photo-1596724817757-41851210875e?auto=format&fit=crop&w=800&q=80',
    tags: ['Pet Friendly', 'Natural Humidifier', 'Tropical Vibe'],
    description: 'Feathery, arching fronds bring a breezy tropical oasis into your living room. 100% non-toxic and safe for curious cats and dogs.',
    careGuide: {
      sunlight: 'Bright indirect light or gentle morning sun. Protect from scorching mid-day rays.',
      watering: 'Keep soil moist during warm months. Allow surface to dry slightly in winter.',
      soil: 'Peat-based potting soil with excellent drainage holes.',
      temperature: '65°F - 75°F. Appreciates regular humidity misting.',
      fertilizer: 'Micro-nutrient rich palm fertilizer every month during summer.'
    }
  },
  {
    id: 'prod-7',
    name: 'Heirloom Culinary Herb Seed Kit (6 Varieties)',
    botanicalName: 'Ocimum basilicum, Rosmarinus, etc.',
    category: 'seeds',
    type: 'Organic Seeds',
    price: 16.50,
    originalPrice: 22.00,
    rating: 4.9,
    reviewsCount: 204,
    stock: 80,
    nurseryId: 'nursery-1',
    nurseryName: 'Urbano Nursery',
    isIndoor: true,
    isOutdoor: true,
    light: 'Full Sun to Partial Shade',
    water: 'Keep Moist for Germination',
    difficulty: 'Easy',
    petFriendly: true,
    image: 'https://images.unsplash.com/photo-1592417817098-8f3d6eb22509?auto=format&fit=crop&w=800&q=80',
    tags: ['Non-GMO', '100% Organic', 'High Germination Rate'],
    description: 'Includes Sweet Italian Basil, Rosemary, Thyme, Mint, Coriander, and Parsley with peat pellets and starter plant markers for your kitchen windowsill.',
    careGuide: {
      sunlight: 'Windowsill with 4-6 hours direct sun or under LED grow lights.',
      watering: 'Mist soil gently daily until sprouts emerge (7-14 days).',
      soil: 'Seed starting mix or sterilized cocopeat starter plugs.',
      temperature: '68°F - 77°F for optimal germination.',
      fertilizer: 'Half-strength seaweed liquid extract once true leaves appear.'
    }
  },
  {
    id: 'prod-8',
    name: 'Artisan Terracotta Ribbed Planter Set (3-Piece)',
    botanicalName: 'Natural Porous Clay',
    category: 'pots',
    type: 'Pots & Planters',
    price: 42.00,
    originalPrice: 55.00,
    rating: 4.9,
    reviewsCount: 57,
    stock: 25,
    nurseryId: 'nursery-1',
    nurseryName: 'Urbano Nursery',
    isIndoor: true,
    isOutdoor: true,
    light: 'N/A',
    water: 'N/A',
    difficulty: 'N/A',
    petFriendly: true,
    image: 'https://images.unsplash.com/photo-1485955900006-10f4d324d411?auto=format&fit=crop&w=800&q=80',
    tags: ['Handcrafted', 'Drainage Hole Included', 'Breathable Clay'],
    description: 'Handcrafted natural porous clay planters with built-in drainage hole and saucer trays. Breathable material protects plant roots from fungal diseases and overwatering.',
    careGuide: {
      sunlight: 'Suitable for indoor consoles or outdoor gardens.',
      watering: 'Porous walls naturally wick away excess root moisture.',
      soil: 'Pair with pot mesh and GreenNest potting substrate.',
      temperature: 'Frost-resistant down to 32°F.',
      fertilizer: 'N/A'
    }
  },
  {
    id: 'prod-9',
    name: 'Ergonomic Titanium Gardening Hand Tool Kit',
    botanicalName: 'Rust-Proof Carbon Steel',
    category: 'tools',
    type: 'Gardening Equipment',
    price: 36.00,
    originalPrice: 45.00,
    rating: 4.8,
    reviewsCount: 132,
    stock: 40,
    nurseryId: 'nursery-2',
    nurseryName: 'Green Eden Botanicals',
    isIndoor: true,
    isOutdoor: true,
    light: 'N/A',
    water: 'N/A',
    difficulty: 'N/A',
    petFriendly: true,
    image: 'https://images.unsplash.com/photo-1416879595882-3373a0480b5b?auto=format&fit=crop&w=800&q=80',
    tags: ['Comfort Grip', 'Rust Proof', 'Includes Canvas Bag'],
    description: 'Heavy-duty 5-piece toolkit featuring bypass pruner, trowel, transplanter, hand rake, and weeder with soft-touch non-slip rubber handles.',
    careGuide: {
      sunlight: 'Store in cool, dry tool shed or tote bag.',
      watering: 'Wipe clean with a damp cloth after use; oil shears periodically.',
      soil: 'N/A',
      temperature: 'N/A',
      fertilizer: 'N/A'
    }
  },
  {
    id: 'prod-10',
    name: 'Organic Vermicompost & Neem Cake Fertilizer (5kg)',
    botanicalName: '100% Pure Earthworm Castings',
    category: 'care',
    type: 'Organic Fertilizer',
    price: 18.00,
    originalPrice: 24.00,
    rating: 4.9,
    reviewsCount: 188,
    stock: 65,
    nurseryId: 'nursery-1',
    nurseryName: 'Urbano Nursery',
    isIndoor: true,
    isOutdoor: true,
    light: 'N/A',
    water: 'N/A',
    difficulty: 'Easy',
    petFriendly: true,
    image: 'https://images.unsplash.com/photo-1585320806297-9794b3e4eeae?auto=format&fit=crop&w=800&q=80',
    tags: ['Organic Certified', 'Microbial Boost', 'Natural Pest Deterrent'],
    description: 'Enriched with beneficial soil microbes and cold-pressed neem cake. Enhances soil aeration, water retention, and root vitality while naturally repelling soil pests.',
    careGuide: {
      sunlight: 'Keep sealed in cool shaded area.',
      watering: 'Mix into topsoil and water deeply.',
      soil: 'Suitable for all potted plants, vegetables, and lawns.',
      temperature: 'Room temperature storage.',
      fertilizer: 'Apply 2 tablespoons per pot every 3 weeks.'
    }
  },
  {
    id: 'prod-11',
    name: 'ZZ Plant (Zamioculcas Zamiifolia)',
    botanicalName: 'Zamioculcas zamiifolia',
    category: 'indoor',
    type: 'Indoor Foliage',
    price: 29.00,
    originalPrice: 36.00,
    rating: 4.9,
    reviewsCount: 95,
    stock: 31,
    nurseryId: 'nursery-1',
    nurseryName: 'Urbano Nursery',
    isIndoor: true,
    isOutdoor: false,
    light: 'Low to Indirect Light',
    water: 'Once every 3 weeks',
    difficulty: 'Very Easy',
    petFriendly: false,
    image: 'https://images.unsplash.com/photo-1632207691143-643e2a9a9361?auto=format&fit=crop&w=800&q=80',
    tags: ['Unkillable', 'Glossy Leaves', 'Low Light Tolerant'],
    description: 'Deep glossy green leaflets arranged on fleshy stems with underground rhizomes storing water. Perfect for dark corners and busy plant parents.',
    careGuide: {
      sunlight: 'Tolerates extreme low light to fluorescent office lamps.',
      watering: 'Drought survivor. Water only when completely dry throughout.',
      soil: 'Cactus and succulent mix with perlite.',
      temperature: '60°F - 80°F.',
      fertilizer: 'Feed balanced formula 2 times a year.'
    }
  },
  {
    id: 'prod-12',
    name: 'Lavender French Scented (Lavandula Dentata)',
    botanicalName: 'Lavandula dentata',
    category: 'outdoor',
    type: 'Aromatic Outdoor',
    price: 22.50,
    originalPrice: 28.00,
    rating: 4.7,
    reviewsCount: 84,
    stock: 20,
    nurseryId: 'nursery-2',
    nurseryName: 'Green Eden Botanicals',
    isIndoor: false,
    isOutdoor: true,
    light: 'Full Sun',
    water: 'Low to Moderate',
    difficulty: 'Medium',
    petFriendly: true,
    image: 'https://images.unsplash.com/photo-1528183429752-a97d0bf99b5a?auto=format&fit=crop&w=800&q=80',
    tags: ['Aromatherapy', 'Pollinator Friendly', 'Natural Insect Repellent'],
    description: 'Fragrant purple flower spikes and silvery-grey foliage. Infuses your balcony or garden path with soothing calming lavender essential scent.',
    careGuide: {
      sunlight: 'Full sun: minimum 6-8 hours daily.',
      watering: 'Allow soil to dry out between deep waterings; sensitive to wet feet.',
      soil: 'Sandy, rocky, alkaline, highly porous soil.',
      temperature: 'Loves heat; hardy in temperatures down to 20°F.',
      fertilizer: 'Needs minimal feeding; excess fertilizer reduces aroma.'
    }
  }
];

export const INITIAL_GARDENERS = [
  {
    id: 'gardener-1',
    name: 'Rajesh Kumar',
    title: 'Master Horticulturalist & Garden Stylist',
    experience: '9+ Years Experience',
    rating: 4.95,
    reviewsCount: 148,
    hourlyRate: 25.00,
    image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&q=80',
    specialties: ['Pruning & Shaping', 'Balcony Garden Makeovers', 'Pest Diagnosis', 'Organic Composting'],
    status: 'Available Today',
    badge: 'Top Rated Pro',
    isVerified: true,
    bio: 'Certified by National Horticultural Board with 9+ years managing luxury estates, terrace gardens, and urban apartment green spaces. Passionate about zero-chemical organic plant care.',
    completedJobs: 320,
    slots: ['09:00 AM', '11:30 AM', '02:00 PM', '04:30 PM']
  },
  {
    id: 'gardener-2',
    name: 'Sunita Sharma',
    title: 'Lawn Care Specialist & Landscape Expert',
    experience: '7+ Years Experience',
    rating: 4.9,
    reviewsCount: 112,
    hourlyRate: 22.00,
    image: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=400&q=80',
    specialties: ['Lawn Mowing & Aeration', 'Drip Irrigation Setup', 'Seasonal Bed Planting', 'Flower Care'],
    status: 'Available Today',
    badge: 'Eco-Certified',
    isVerified: true,
    bio: 'Specialist in turf rejuvenation, hedge sculpturing, and sustainable water-saving irrigation setups. Has revived over 200+ residential lawns.',
    completedJobs: 245,
    slots: ['10:00 AM', '01:00 PM', '03:30 PM', '05:00 PM']
  },
  {
    id: 'gardener-3',
    name: 'Manoj Patel',
    title: 'Plant Health & Soil Revitalization Specialist',
    experience: '12+ Years Experience',
    rating: 4.88,
    reviewsCount: 189,
    hourlyRate: 28.00,
    image: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=400&q=80',
    specialties: ['Bonsai Training', 'Disease & Fungal Cure', 'Tree Care', 'Soil Nutrient Balancing'],
    status: 'Booked Tomorrow',
    badge: 'Veteran Specialist',
    isVerified: true,
    bio: 'Former senior curator at botanic research gardens. Expert in saving distressed, root-bound, or pest-infested exotic houseplants and fruit trees.',
    completedJobs: 410,
    slots: ['09:30 AM', '12:00 PM', '03:00 PM']
  }
];

export const INITIAL_SERVICES = [
  {
    id: 'serv-1',
    name: 'Comprehensive Home Gardening & Maintenance',
    tagline: 'Complete care package for potted plants, balcony & indoor greenery',
    icon: 'Leaf',
    duration: '2 - 3 Hours',
    price: 49.00,
    includes: [
      'Deep soil loosening & aeration for all pots',
      'Pruning of dry, yellowing, or dead leaves & branches',
      'Application of organic vermicompost & micronutrients',
      'Eco-friendly neem oil pest wash & leaf shine',
      'Custom watering & placement advice for each plant'
    ]
  },
  {
    id: 'serv-2',
    name: 'Lawn Mowing & Turf Care Package',
    tagline: 'Precision grass trimming, edging, weed removal & fertilization',
    icon: 'Sun',
    duration: '2 - 4 Hours',
    price: 59.00,
    includes: [
      'Rotary lawn mowing with adjustable height precision',
      'Clean edge border trimming along paths & flowerbeds',
      'Thatch removal & soil aeration',
      'Slow-release organic lawn fertilizer application',
      'Green debris raking & tidy eco-disposal'
    ]
  },
  {
    id: 'serv-3',
    name: 'Plant Health Diagnosis & Pest Eradication',
    tagline: 'Targeted cure for yellowing leaves, mealybugs, aphids & root rot',
    icon: 'ShieldCheck',
    duration: '1.5 - 2 Hours',
    price: 39.00,
    includes: [
      'Thorough inspection of foliage, stem, and root health',
      'Identification of fungal or bacterial blights & insects',
      'Targeted bio-organic antifungal and pest treatment',
      'Root check, corrective repotting & root trim if rotted',
      'Personalized 14-day recovery care calendar'
    ]
  },
  {
    id: 'serv-4',
    name: 'Balcony & Terrace Garden Setup Consultation',
    tagline: 'Transform plain balconies into lush, blooming urban sanctuaries',
    icon: 'Compass',
    duration: '2 Hours',
    price: 69.00,
    includes: [
      'Sunlight angle analysis and wind exposure assessment',
      'Optimal plant selection customized to balcony dimensions',
      'Planter layout design & vertical railing plant arrangement',
      'Soil preparation and planting of up to 6 starter pots',
      'Automated drip watering kit recommendations'
    ]
  }
];

export const INITIAL_ORDERS = [
  {
    id: 'ORD-98214',
    date: '2026-09-18T10:30:00Z',
    customerName: 'Aarav Sharma',
    customerEmail: 'aarav.sharma@example.com',
    customerPhone: '+91 98765 43210',
    address: 'Flat 402, Green Meadows Residency, Indiranagar, Bengaluru, 560038',
    items: [
      {
        id: 'prod-1',
        name: 'Monstera Deliciosa (Swiss Cheese Plant)',
        price: 34.99,
        quantity: 1,
        image: 'https://images.unsplash.com/photo-1614594975525-e45190c55d0b?auto=format&fit=crop&w=400&q=80',
        nurseryName: 'Urbano Nursery'
      },
      {
        id: 'prod-8',
        name: 'Artisan Terracotta Ribbed Planter Set (3-Piece)',
        price: 42.00,
        quantity: 1,
        image: 'https://images.unsplash.com/photo-1485955900006-10f4d324d411?auto=format&fit=crop&w=400&q=80',
        nurseryName: 'Urbano Nursery'
      }
    ],
    subtotal: 76.99,
    discount: 7.70, // 10% coupon
    packagingFee: 2.00,
    deliveryFee: 0.00,
    total: 71.29,
    status: 'Out for Delivery', // 'Placed', 'Packed', 'Out for Delivery', 'Delivered'
    paymentMethod: 'UPI / Online Card',
    trackingNumber: 'GN-EXP-449102',
    estimatedDelivery: 'Today by 5:00 PM'
  },
  {
    id: 'ORD-98105',
    date: '2026-09-15T14:15:00Z',
    customerName: 'Aarav Sharma',
    customerEmail: 'aarav.sharma@example.com',
    customerPhone: '+91 98765 43210',
    address: 'Flat 402, Green Meadows Residency, Indiranagar, Bengaluru, 560038',
    items: [
      {
        id: 'prod-2',
        name: 'Sansevieria Trifasciata (Snake Plant)',
        price: 24.50,
        quantity: 2,
        image: 'https://images.unsplash.com/photo-1593482892290-f54927ae1bf6?auto=format&fit=crop&w=400&q=80',
        nurseryName: 'Urbano Nursery'
      },
      {
        id: 'prod-10',
        name: 'Organic Vermicompost (5kg)',
        price: 18.00,
        quantity: 1,
        image: 'https://images.unsplash.com/photo-1585320806297-9794b3e4eeae?auto=format&fit=crop&w=400&q=80',
        nurseryName: 'Urbano Nursery'
      }
    ],
    subtotal: 67.00,
    discount: 0.00,
    packagingFee: 2.00,
    deliveryFee: 0.00,
    total: 69.00,
    status: 'Delivered',
    paymentMethod: 'Cash on Delivery',
    trackingNumber: 'GN-EXP-447812',
    estimatedDelivery: 'Delivered on Sep 16, 2026'
  }
];

export const INITIAL_BOOKINGS = [
  {
    id: 'BKG-5412',
    serviceId: 'serv-1',
    serviceName: 'Comprehensive Home Gardening & Maintenance',
    gardenerId: 'gardener-1',
    gardenerName: 'Rajesh Kumar',
    gardenerPhone: '+91 98450 11223',
    customerName: 'Aarav Sharma',
    customerEmail: 'aarav.sharma@example.com',
    customerPhone: '+91 98765 43210',
    address: 'Flat 402, Green Meadows Residency, Indiranagar, Bengaluru, 560038',
    gardenType: 'Balcony & Indoor (18 Potted Plants)',
    date: '2026-09-20',
    timeSlot: '11:30 AM',
    price: 49.00,
    status: 'Confirmed', // 'Requested', 'Confirmed', 'In Progress', 'Completed', 'Cancelled'
    notes: 'Please prune the climbing monstera and inspect peace lily leaves for brown spots.',
    paymentStatus: 'Paid Online'
  },
  {
    id: 'BKG-5390',
    serviceId: 'serv-3',
    serviceName: 'Plant Health Diagnosis & Pest Eradication',
    gardenerId: 'gardener-1',
    gardenerName: 'Rajesh Kumar',
    gardenerPhone: '+91 98450 11223',
    customerName: 'Priya Mehra',
    customerEmail: 'priya.m@example.com',
    customerPhone: '+91 97112 33445',
    address: 'House #12, 4th Cross, Koramangala 3rd Block, Bengaluru',
    gardenType: 'Terrace Garden (35 Pots)',
    date: '2026-09-17',
    timeSlot: '02:00 PM',
    price: 39.00,
    status: 'Completed',
    notes: 'Mealybugs found on hibiscus and curry leaf plant.',
    paymentStatus: 'Paid Online'
  }
];

export const INITIAL_APPLICATIONS = [
  {
    id: 'APP-101',
    name: 'Nature Bloom Nursery',
    type: 'Nursery Vendor',
    contactPerson: 'Vikram Joshi',
    email: 'naturebloom@example.com',
    phone: '+91 98223 99112',
    location: 'Whitefield, Bengaluru',
    licenseNumber: 'KA-AGRI-2026-904',
    status: 'Pending', // 'Pending', 'Approved', 'Rejected'
    appliedDate: '2026-09-18',
    details: 'Organic plant nursery specializing in exotic succulents, bonsai, and indigenous medicinal flora.'
  },
  {
    id: 'APP-102',
    name: 'Anil Verma',
    type: 'Gardener Pro',
    contactPerson: 'Anil Verma',
    email: 'anil.gardens@example.com',
    phone: '+91 98110 55678',
    location: 'HSR Layout, Bengaluru',
    licenseNumber: 'CERT-HORT-8831',
    status: 'Pending',
    appliedDate: '2026-09-17',
    details: 'Diploma in Landscape Architecture with 6 years experience in terrace drip setups.'
  }
];

export const INITIAL_DISPUTES = [
  {
    id: 'DISP-801',
    orderOrBookingId: 'ORD-97810',
    type: 'Damaged Plant in Transit',
    customerName: 'Neha Rao',
    vendorOrGardener: 'Green Eden Botanicals',
    description: 'The ceramic pot was cracked upon courier delivery, though plant stems are intact.',
    status: 'Open', // 'Open', 'Resolved', 'Investigating'
    date: '2026-09-18',
    resolutionNote: ''
  },
  {
    id: 'DISP-802',
    orderOrBookingId: 'BKG-5299',
    type: 'Gardener Reschedule Request',
    customerName: 'Karan Singh',
    vendorOrGardener: 'Rajesh Kumar',
    description: 'Customer requested emergency reschedule due to travel.',
    status: 'Resolved',
    date: '2026-09-14',
    resolutionNote: 'Rescheduled seamlessly to Sunday 10 AM without cancellation fee.'
  }
];

export const INITIAL_NOTIFICATIONS = [
  {
    id: 'notif-1',
    title: 'Order Dispatched! 🌿',
    message: 'Your order ORD-98214 from Urbano Nursery is out for delivery with eco-carrier.',
    time: '25 mins ago',
    isRead: false,
    type: 'order'
  },
  {
    id: 'notif-2',
    title: 'Gardener Booking Confirmed 👨‍🌾',
    message: 'Rajesh Kumar confirmed your visit for Tomorrow at 11:30 AM.',
    time: '2 hours ago',
    isRead: false,
    type: 'booking'
  },
  {
    id: 'notif-3',
    title: 'Plant Care Reminder 💧',
    message: 'Time to check soil moisture for your Monstera Deliciosa.',
    time: 'Yesterday',
    isRead: true,
    type: 'care'
  }
];
